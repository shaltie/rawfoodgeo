jQuery(document).ready(function($){

		//jQuery(".tt_colorbox_iframe").colorbox({iframe:true, innerWidth:640, innerHeight:390, transition: 'fade'});
		jQuery(".tt_colorbox_iframe").colorbox({iframe:true, innerWidth:'90%', maxWidth:640, maxHeight:390, innerHeight:'90%', transition: 'fade'});

		
});


