jQuery(document).ready(function($){

		
		$('.ttshowcase_masonry').each(function() {
				var msnry = new Masonry( this, {
			  		itemSelector: '.ttshowcase_rl_box'
				});	

		});

});