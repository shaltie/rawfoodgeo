<?php


add_shortcode('fmr_users', 'fmr_dialog_show_users');

function fmr_dialog_show_users(){
    ?>
   
   		<div class="members_in_wrap2 ">
						<?php
								
						$mycity_params = array(
							'orderby' => 'ID',  
							'order' => 'ASC',
							'number' => 0
						);
						$mycity_uq = new WP_User_Query($mycity_params);
                        
						//$mycity_style = get_theme_mod("members_memberliststyle", "s1");
						
						foreach ($mycity_uq->results as $mycity_user) {
						?>
                        
                        <div class="frm_dialog_user_block">
    <div class="members_item">
        <a id="frm_dialog_open"  onclick="openUserPrivate(<?php echo (int)$mycity_user->ID; ?>)" class="frm_d_a_members">
 
            <?php
            $mycity_params = array('width' =>128, 'height' => 128, 'crop' => true );
           
            $avatar = get_avatar($mycity_user->ID,128);        
        
            $mycity_img_url=  bfi_thumb(frm_dilaog_get_url_by_avatar($avatar), $mycity_params);
            ?>
           <img src="<?php echo esc_url($mycity_img_url); ?>" width="128" height="128" alt="">
           
            <div class="frm_d_happy_f_block_hover">
                <div class="frm_d_plus-hover-content">
                    <i class="fa fa-plus fa-3x"></i>
                </div>
            </div>
        </a>        
         <p class="frm_d_member_name"><?php echo esc_html($mycity_user->display_name); ?></p>
        
    
    </div>
</div>
                        <?php
						}
						
						?>	
					</div>
    <?php
}

function frm_dilaog_get_url_by_avatar($get_avatar){
		preg_match("/src=['\"](.*?)['\"]/i", $get_avatar , $matches);        
		return  (isset($matches[1])) ? $matches[1] : "";
	}