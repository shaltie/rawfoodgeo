<?php


    
function fmr_dialog_color(){
    
    $blue = get_theme_mod('fmr_dialogshead_color','#0084ff');
    $body_message = get_theme_mod('fmr_dialogsbody_color','#f8f3ef');
    $border_mesege =  get_theme_mod('fmr_dialogsborder_color','#f0e8e2');
    $fmr_chat_right = fmr_dialog_hex2rgb(get_theme_mod('fmr_dialogsuser_body_color','#000'));
    $buton_plus =  get_theme_mod('fmr_dialogsbuton_plus_color','#ffd200');
    
    $css = ".fmr_chat_header, .chat_message_out, .fmr_chat_right .unreaded {background: $blue;}";
    $css .= ".chat_message_out:after{ color:$blue }";
    $css .= ".fmr_chat_messages{background:   $body_message;}";
    $css .= ".chat_message_in, .fmr_chat_send, .smail_imgs{ background: $border_mesege;  }";
    $css .= ".fmr_chat_right{ background: rgba($fmr_chat_right,0.6);  }";
    $css .= ".add_fmr_chat_item .fmr_chat_item_circle{ background:  $buton_plus;  }";
    //fmr_dialogsuser_body_color
    
    
    return $css;
    
}

function  fmr_dialog_hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   return implode(",", $rgb); // returns the rgb values separated by commas
   //return $rgb; // returns an array with the rgb values
}