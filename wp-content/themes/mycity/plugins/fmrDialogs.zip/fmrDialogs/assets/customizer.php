<?php

function fmr_dialog_customizer_init($wp_customize) {
    
    
    //Panels
    $wp_customize->add_panel('frm_panel_dialog', array(
        'title' => esc_html__('Dialogs', 'mycity'),
        'description' => esc_html__('Settings of the main page', 'mycity'),
         'priority' => 5,
    ));
    
    

    /*-------------------------------skills ------------------------------*/
  $tmp_sectionname = "fmr_dialogs";
    $wp_customize->add_section($tmp_sectionname . '_section2', array(
        'title' => esc_html__('ID', 'mycity'),
        'priority' => 29,
        'description' => esc_html__("show everyone in the user's contact list with an id",'fmr'),
        'panel' => 'frm_panel_dialog'));
    $tmp_settingname = $tmp_sectionname . '_userid';
    $wp_customize->add_setting($tmp_settingname, array('default' => '', 'sanitize_callback' => 'esc_html'));

    $wp_customize->add_control($tmp_settingname . '_control', array(
        'label' => esc_html__('Enter User ID', 'mycity'),
        'section' => $tmp_sectionname . "_section2",
        'settings' => $tmp_settingname,
        'type' => 'text'
    ));
    
    /*---------------------------------colors-----------------------------*/

    
    // add new section
    
$wp_customize->add_section( $tmp_sectionname . '_colors', array(
	'title' => __( 'Dialogs Colors', 'frm' ),
	'priority' => 100,
    'panel' => 'frm_panel_dialog'    
) );



// add color picker setting

$tmp_settingname = $tmp_sectionname . 'head_color';
$wp_customize->add_setting( $tmp_settingname, array(
	'default' => '#0084ff'
) );

// add color picker control
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $tmp_settingname, array(
	'label' =>   esc_html__('head color','fmr'),    
	'section' =>$tmp_sectionname . '_colors',
	'settings' =>$tmp_settingname,
) ) );


// add color picker setting body
$tmp_settingname = $tmp_sectionname . 'body_color';

$wp_customize->add_setting( $tmp_settingname, array(
	'default' => '#f8f3ef'
) );

// add color picker control
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $tmp_settingname, array(
	'label' =>  esc_html__('body color','fmr'),
	'section' =>$tmp_sectionname . '_colors',
	'settings' => $tmp_settingname,
) ) );


// add color picker setting  border
$tmp_settingname = $tmp_sectionname. 'border_color';

$wp_customize->add_setting( $tmp_settingname, array(
	'default' => '#f0e8e2'
) );

// add color picker control
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $tmp_settingname, array(
	'label' =>  esc_html__('border color','fmr'),
	'section' =>$tmp_sectionname . '_colors',
	'settings' => $tmp_settingname,
) ) );

    
    
/*********************** add color picker setting  body users*****************/
$tmp_settingname = $tmp_sectionname. 'user_body_color';

$wp_customize->add_setting( $tmp_settingname, array(
	'default' => '#000'
) );

// add color picker control
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $tmp_settingname, array(
	'label' => esc_html__( 'border color users','fmr'),
	'section' =>$tmp_sectionname . '_colors',
	'settings' => $tmp_settingname,
) ) );

    /*********************** add color picker setting  buton +*****************/
$tmp_settingname = $tmp_sectionname. 'buton_plus_color';

$wp_customize->add_setting( $tmp_settingname, array(
	'default' => '#000'
) );

// add color picker control
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $tmp_settingname, array(
	'label' =>  esc_html__(' Color buton +','fmr'),
	'section' =>$tmp_sectionname . '_colors',
	'settings' => $tmp_settingname,
) ) );
    
}
add_action('customize_register', 'fmr_dialog_customizer_init');


