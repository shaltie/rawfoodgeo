/* Ladda.min.js MIT by hakimel https://github.com/hakimel/Ladda */
(function(l,h){"use strict";"object"==typeof exports?module.exports=h():"function"==typeof define&&define.amd?define(h):l.Spinner=h()})(this,function(){function l(k,b){var d,a=document.createElement(k||"div");for(d in b)a[d]=b[d];return a}function h(k){for(var b=1,d=arguments.length;d>b;b++)k.appendChild(arguments[b]);return k}function v(k,b,d,a){var e=["opacity",b,~~(100*k),d,a].join("-");d=.01+d/a*100;a=Math.max(1-(1-k)/b*(100-d),k);var c=m.substring(0,m.indexOf("Animation")).toLowerCase();return u[e]||(r.insertRule("@"+
(c&&"-"+c+"-"||"")+"keyframes "+e+"{0%{opacity:"+a+"}"+d+"%{opacity:"+k+"}"+(d+.01)+"%{opacity:1}"+(d+b)%100+"%{opacity:"+k+"}100%{opacity:"+a+"}}",r.cssRules.length),u[e]=1),e}function n(k,b){var d,a,e=k.style;if(void 0!==e[b])return b;b=b.charAt(0).toUpperCase()+b.slice(1);for(a=0;c.length>a;a++)if(d=c[a]+b,void 0!==e[d])return d}function a(k,b){for(var a in b)k.style[n(k,a)||a]=b[a];return k}function f(a){for(var b=1;arguments.length>b;b++){var d=arguments[b],c;for(c in d)void 0===a[c]&&(a[c]=
d[c])}return a}function t(a){for(var b={x:a.offsetLeft,y:a.offsetTop};a=a.offsetParent;)b.x+=a.offsetLeft,b.y+=a.offsetTop;return b}function g(a){return void 0===this?new g(a):(this.opts=f(a||{},g.defaults,w),void 0)}function p(){function k(b,a){return l("<"+b+' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">',a)}r.addRule(".spin-vml","behavior:url(#default#VML)");g.prototype.lines=function(b,d){function c(){return a(k("group",{coordsize:g+" "+g,coordorigin:-f+" "+-f}),{width:g,height:g})}
function e(b,e,m){h(t,h(a(c(),{rotation:360/d.lines*b+"deg",left:~~e}),h(a(k("roundrect",{arcsize:d.corners}),{width:f,height:d.width,left:d.radius,top:-d.width>>1,filter:m}),k("fill",{color:d.color,opacity:d.opacity}),k("stroke",{opacity:0}))))}var m,f=d.length+d.width,g=2*f;m=2*-(d.width+d.length)+"px";var t=a(c(),{position:"absolute",top:m,left:m});if(d.shadow)for(m=1;d.lines>=m;m++)e(m,-2,"progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");for(m=1;d.lines>=m;m++)e(m);
return h(b,t)};g.prototype.opacity=function(b,a,k,e){b=b.firstChild;e=e.shadow&&e.lines||0;b&&b.childNodes.length>a+e&&(b=b.childNodes[a+e],b=b&&b.firstChild,b=b&&b.firstChild,b&&(b.opacity=k))}}var m,c=["webkit","Moz","ms","O"],u={},r=function(){var a=l("style",{type:"text/css"});return h(document.getElementsByTagName("head")[0],a),a.sheet||a.styleSheet}(),w={lines:12,length:7,width:5,radius:10,rotate:0,corners:1,color:"#000",direction:1,speed:1,trail:100,opacity:.25,fps:20,zIndex:2E9,className:"spinner",
top:"auto",left:"auto",position:"relative"};g.defaults={};f(g.prototype,{spin:function(k){this.stop();var b,d,c=this,e=c.opts,f=c.el=a(l(0,{className:e.className}),{position:e.position,width:0,zIndex:e.zIndex}),g=e.radius+e.length+e.width;if(k&&(k.insertBefore(f,k.firstChild||null),d=t(k),b=t(f),a(f,{left:("auto"==e.left?d.x-b.x+(k.offsetWidth>>1):parseInt(e.left,10)+g)+"px",top:("auto"==e.top?d.y-b.y+(k.offsetHeight>>1):parseInt(e.top,10)+g)+"px"})),f.setAttribute("role","progressbar"),c.lines(f,
c.opts),!m){var h,q=0,w=(e.lines-1)*(1-e.direction)/2,n=e.fps,p=n/e.speed,r=(1-e.opacity)/(p*e.trail/100),u=p/e.lines;(function x(){q++;for(var a=0;e.lines>a;a++)h=Math.max(1-(q+(e.lines-a)*u)%p*r,e.opacity),c.opacity(f,a*e.direction+w,h,e);c.timeout=c.el&&setTimeout(x,~~(1E3/n))})()}return c},stop:function(){var a=this.el;return a&&(clearTimeout(this.timeout),a.parentNode&&a.parentNode.removeChild(a),this.el=void 0),this},lines:function(c,b){function d(c,d){return a(l(),{position:"absolute",width:b.length+
b.width+"px",height:b.width+"px",background:c,boxShadow:d,transformOrigin:"left",transform:"rotate("+~~(360/b.lines*e+b.rotate)+"deg) translate("+b.radius+"px,0)",borderRadius:(b.corners*b.width>>1)+"px"})}for(var f,e=0,g=(b.lines-1)*(1-b.direction)/2;b.lines>e;e++)f=a(l(),{position:"absolute",top:1+~(b.width/2)+"px",transform:b.hwaccel?"translate3d(0,0,0)":"",opacity:b.opacity,animation:m&&v(b.opacity,b.trail,g+e*b.direction,b.lines)+" "+1/b.speed+"s linear infinite"}),b.shadow&&h(f,a(d("#000","0 0 4px #000"),
{top:"2px"})),h(c,h(f,d(b.color,"0 0 1px rgba(0,0,0,.1)")));return c},opacity:function(a,b,c){a.childNodes.length>b&&(a.childNodes[b].style.opacity=c)}});var q=a(l("group"),{behavior:"url(#default#VML)"});return!n(q,"transform")&&q.adj?p():m=n(q,"animation"),g});(function(l,h){"object"==typeof exports?module.exports=h():"function"==typeof define&&define.amd?define(["spin"],h):l.Ladda=h(l.Spinner)})(this,function(l){function h(a){if(void 0===a)return console.warn("Ladda button target must be defined."),void 0;a.querySelector(".ladda-label")||(a.innerHTML='<span class="ladda-label">'+a.innerHTML+"</span>");var f,h=document.createElement("span");h.className="ladda-spinner";a.appendChild(h);var g,p={start:function(){if(!f){var m,c=a.offsetHeight;0===c&&(c=parseFloat(window.getComputedStyle(a).height));
32<c&&(c*=.8);a.hasAttribute("data-spinner-size")&&(c=parseInt(a.getAttribute("data-spinner-size"),10));a.hasAttribute("data-spinner-color")&&(m=a.getAttribute("data-spinner-color"));c*=.2;f=new l({color:m||"#fff",lines:12,radius:c,length:.6*c,width:7>c?2:3,zIndex:"auto",top:"auto",left:"auto",className:""})}return a.setAttribute("disabled",""),a.setAttribute("data-loading",""),clearTimeout(g),f.spin(h),this.setProgress(0),this},startAfter:function(a){return clearTimeout(g),g=setTimeout(function(){p.start()},
a),this},stop:function(){return a.removeAttribute("disabled"),a.removeAttribute("data-loading"),clearTimeout(g),f&&(g=setTimeout(function(){f.stop()},1E3)),this},toggle:function(){return this.isLoading()?this.stop():this.start(),this},setProgress:function(f){f=Math.max(Math.min(f,1),0);var c=a.querySelector(".ladda-progress");0===f&&c&&c.parentNode?c.parentNode.removeChild(c):(c||(c=document.createElement("div"),c.className="ladda-progress",a.appendChild(c)),c.style.width=(f||0)*a.offsetWidth+"px")},
enable:function(){return this.stop(),this},disable:function(){return this.stop(),a.setAttribute("disabled",""),this},isLoading:function(){return a.hasAttribute("data-loading")}};return n.push(p),p}function v(a){for(var f=[],h=0;a.length>h;h++)f.push(a[h]);return f}var n=[];return{bind:function(a,f){f=f||{};var l=[];"string"==typeof a?l=v(document.querySelectorAll(a)):"object"==typeof a&&"string"==typeof a.nodeName&&(l=[a]);for(var g=0,p=l.length;p>g;g++)(function(){var a=l[g];if("function"==typeof a.addEventListener){var c=
h(a),p=-1;a.addEventListener("click",function(){for(var h=!0,g,l=a;l.parentNode&&"FORM"!==l.tagName;)l=l.parentNode;g="FORM"===l.tagName?l:void 0;if(void 0!==g){for(var k=["input","textarea"],l=[],b=0;k.length>b;b++)for(var d=g.getElementsByTagName(k[b]),n=0;d.length>n;n++)d[n].hasAttribute("required")&&l.push(d[n]);for(g=0;l.length>g;g++)""===l[g].value.replace(/^\s+|\s+$/g,"")&&(h=!1)}h&&(c.startAfter(1),"number"==typeof f.timeout&&(clearTimeout(p),p=setTimeout(c.stop,f.timeout)),"function"==typeof f.callback&&
f.callback.apply(null,[c]))},!1)}})()},create:h,stopAll:function(){for(var a=0,f=n.length;f>a;a++)n[a].stop()}}});Ladda.bind(".ladda-primary",{timeout:800,callback:function(l){}});

/* end */

jQuery(document).ready(function(){
	jQuery(document).on("click",'.send-message',function(e){
		snd();
	});
});
jQuery(document).ready(
	
	function(){
		jQuery('#txtm').on('keyup', function(e) {
		if (e.which == 13 && ! e.shiftKey) {
			snd();
		}
	});
	//rel();
});
function snd() {
	jQuery.post(pluginsUrl +"/fmrDialogs/ajax.php?msg_send="+user2,{msg:jQuery("#txtm").val()},function(d){
		jQuery("#msg23").html(d);
		var elem = document.getElementById('msg23');
		elem.scrollTop = elem.scrollHeight;
		rel();
	});
	jQuery("#txtm").val("");
}
function rel() {
	//alert(1);
	jQuery.get(pluginsUrl +"/fmrDialogs/ajax.php?msg_get="+user2,function(d){
	jQuery("#msg23").html(d);
	var elem = document.getElementById('msg23');
	elem.scrollTop = elem.scrollHeight;
	});
}

function ladda_gochat(dom,url){

	var l = Ladda.create( dom);
    l.start();
	jQuery(".fmr_chatframe","body").show();
	jQuery("#fmr_chatframe").prop("src",url);
	jQuery("#fmr_chatframe").on("load",function(){l.stop();});
    jQuery('#fmr_chatframe').show();
}

function openUserPrivate(id) { 
	jQuery(".fmr_chatframe","body").show();
  	jQuery('#fmr_chatframe').show();
	var url = pluginsUrl +"/fmrDialogs/dialog_window.php?user2="+id+"&xframe=1";
	jQuery("#fmr_chatframe").prop("src",url);
};
jQuery(document).ready(function($) {
    
    
    $('a.frm_dialog_open').click(function(e){
        e.preventDefault();
    });
       jQuery('#fmr_chatframe').load(function(){

        var iframe = jQuery('#fmr_chatframe').contents();

        var div = iframe.find("#msg23");
        div.scrollTop(div.prop('scrollHeight'));
        iframe.find(".fmr_chat_ava_exit a").click(function(){
				jQuery('#fmr_chatframe').prop("src","");
            	jQuery('#fmr_chatframe').hide();
                
                
                
        });
        
  
    });
 });
 
 