<?php 
	
if ( !defined('ABSPATH') ) {
/** Set up WordPress environment */
require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

if (isset($_GET['msg_send'])) {
	if (strlen($_POST['msg']) < 3) die();
	$wpdb->insert( 
		$wpdb->prefix.'dialog', 
		array( 
			'user1' => get_current_user_id(), 
			'user2' => (int)$_GET['msg_send'],
			'dataadd' => time(),
			'msg' => esc_textarea ( $_POST['msg'] )
		), 
		array( 
			'%d', 
			'%d',
			'%d',
			'%s'
		) 
	);
	fmr_chat_messages(get_current_user_id(),esc_textarea($_GET['msg_send']));
}

if (isset($_GET['msg_get'])) {
	$id = get_current_user_id();
	fmr_chat_messages($id,esc_textarea($_GET['msg_get']));
} 


?>