<?php
/**
 * Template Name: Chat dialog
 * Preview: http://chat.vioo.ru/dialog.html
 */
// show_admin_bar(false);

if ( !defined('ABSPATH') ) {
/** Set up WordPress environment */
require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

if (!function_exists('imap_open')) {
    
    function fmr_num2str($r)
    {
        return $r;
    }
}
    
/*
*/
?><html><?
wp_head();

if (!get_current_user_id()) {
}

global $myFrame_dditional;

if (!isset($_GET['xframe'])) $myFrame_dditional = " dialogpage";
?>
    
	<script>
        var user2 = '<?php echo (int)$_GET['user2']?>';
    </script>
<body>
    <div class="fmr_chat_box">
        <div class="container2 fmr_chat_overflow">
            <div class="row2">
                <div class="col-md-122 fmr_chat fmr_chat_static">
                    <div class="fmr_chat_container">
                        <?php
                        if (isset($_GET['user2'])) {
                            $user2 = get_users("include=" . (int)$_GET['user2']);
                            $user2 = $user2[0];
                            ?>
                            <div class="fmr_chat_header clearfix">
                                <div class="cell">
                                    <div class="fmr_chat_ava pull-left">
                                        <?php
                                        echo get_avatar($user2->ID, 30);
                                        ?>
                                    </div>
                                    <div class="fmr_chat_ava_name pull-left">
                                        <a href="/members/<?php echo esc_attr($user2->ID); ?>">
                                            <p><?php echo  esc_attr($user2->display_name); ?></p>
                                        </a>
                                    </div>
                                    <div class="fmr_chat_ava_exit visible-xs">
                                        <a href="#" class="close-dialog">
                                     
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!-- chat messages -->
                            <div id="msg23" class="fmr_chat_messages clearfix">
                                <?php
                                fmr_chat_messages(get_current_user_id(), (int)$_GET['user2']);
                                ?>
                            </div>

                            <!-- chat send -->


                            <div class="fmr_chat_send clearfix">
                                <div class="smail_imgs">

                                    <a href="#" data-smail=":)"><?php echo wp_kses_post(convert_smilies(":)")); ?></a>
                                    <a href="#" data-smail=":D"><?php echo wp_kses_post(convert_smilies(":D")); ?></a>
                                    <a href="#" data-smail=":("><?php echo wp_kses_post(convert_smilies(":(")); ?></a>
                                    <a href="#" data-smail=":o"><?php echo wp_kses_post(convert_smilies(":o")); ?></a>
                                    <a href="#" data-smail="8O"><?php echo wp_kses_post(convert_smilies("8O")); ?></a>
                                    <a href="#" data-smail=":?"><?php echo wp_kses_post(convert_smilies(":?")); ?></a>
                                    <a href="#"
                                       data-smail=":cool:"><?php echo wp_kses_post(convert_smilies(":cool:")); ?></a>
                                    <a href="#" data-smail=":x"><?php echo wp_kses_post(convert_smilies(":x")); ?></a>
                                    <a href="#" data-smail=":P"><?php echo wp_kses_post(convert_smilies(":P")); ?></a>
                                    <a href="#" data-smail=":|"><?php echo wp_kses_post(convert_smilies(":|")); ?></a>
                                    <a href="#" data-smail=";)"><?php echo wp_kses_post(convert_smilies(";)")); ?></a>
                                    <a href="#"
                                       data-smail=":lol:"><?php echo wp_kses_post(convert_smilies(":lol:")); ?></a>
                                    <a href="#"
                                       data-smail=":oops:"><?php echo wp_kses_post(convert_smilies(":oops:")); ?></a>
                                    <a href="#"
                                       data-smail=":cry:"><?php echo wp_kses_post(convert_smilies(":cry:")); ?></a>
                                    <a href="#"
                                       data-smail=":evil:"><?php echo wp_kses_post(convert_smilies(":evil:")); ?></a>
                                    <a href="#"
                                       data-smail=":twisted:"><?php echo wp_kses_post(convert_smilies(":twisted:")); ?></a>
                                    <a href="#"
                                       data-smail=":roll:"><?php echo wp_kses_post(convert_smilies(":roll:")); ?></a>
                                    <a href="#" data-smail=":!:"><?php echo wp_kses_post(convert_smilies(":!:")); ?></a>
                                    <a href="#" data-smail=":?:"><?php echo wp_kses_post(convert_smilies(":?:")); ?></a>
                                    <a href="#"
                                       data-smail=":idea:"><?php echo wp_kses_post(convert_smilies(":idea:")); ?></a>
                                    <a href="#"
                                       data-smail=":arrow:"><?php echo wp_kses_post(convert_smilies(":arrow:")); ?></a>
                                    <a href="#"
                                       data-smail=":mrgreen:"><?php echo wp_kses_post(convert_smilies(":mrgreen:")); ?></a>


                                </div>
						<textarea type="text" style="border:1px solid white;resize:none" id="txtm"
                                  class="fmr_chat_send_text"></textarea>


                                <a class="fmr_chat_smails" href="#">
                                    <img src="<?php echo plugins_url(); ?>/fmrDialogs/images/smile_form.png"
                                         height="16" class="fmr_chat_smile" width="16" alt=""></a>
                                                              <!-- <input onclick="snd()" type="submit" value="" class="btn-send-chat"> -->
                                <button class="send-message"></button>
                            </div>
                        <?php } else {
                            ?>Select one<?php
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        jQuery(document).ready(function ($) {


$("body").click(function(e) {
 if($(e.target).closest(".smail_imgs img").length==0 &&  $(e.target).closest(".fmr_chat_smile").length==0 ) $(".smail_imgs").css("display","none");

});


/*$('body').click(function (event) {
    console.log(event.target);
});*/

            jQuery('.fmr_chat_smile').click(function (e) {
                e.preventDefault();                               
                 jQuery('.smail_imgs').show();
            });
            
            

            jQuery('.smail_imgs a').click(function (e) {

                $('.smail_imgs').hide();
                $('.fmr_chat_send_text').insertAtCaret(" " + $(this).data('smail') + " ");

            });


        });

        jQuery.fn.extend({
            insertAtCaret: function (myValue) {
                return this.each(function (i) {
                    if (document.selection) {
                        // Internet Explorer
                        this.focus();
                        var sel = document.selection.createRange();
                        sel.text = myValue;
                        this.focus();
                    }
                    else if (this.selectionStart || this.selectionStart == '0') {
                        //  Firefox and Webkit
                        var startPos = this.selectionStart;
                        var endPos = this.selectionEnd;
                        var scrollTop = this.scrollTop;
                        this.value = this.value.substring(0, startPos) + myValue + this.value.substring(endPos, this.value.length);
                        this.focus();
                        this.selectionStart = startPos + myValue.length;
                        this.selectionEnd = startPos + myValue.length;
                        this.scrollTop = scrollTop;
                    } else {
                        this.value += myValue;
                        this.focus();
                    }
                })
            }
        });
    </script>


<?php
wp_footer(); ?>
<body>
</html>