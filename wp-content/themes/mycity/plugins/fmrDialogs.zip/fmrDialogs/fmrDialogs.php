<?php
/*
Plugin Name: Fmr Dialogs
Plugin URI: 
Description: Add small dialogs winodw for people chating
Version: 1.1
Author: Alex and Victor Lerner
Author URI: 
License: 
*/
define("FRM_PLUGIN_DIR_PATH", plugin_dir_path(__FILE__));
require FRM_PLUGIN_DIR_PATH . '/assets/customizer.php';
require FRM_PLUGIN_DIR_PATH . '/assets/css_generator.php';
require FRM_PLUGIN_DIR_PATH . '/assets/shortcode.php';
require_once FRM_PLUGIN_DIR_PATH . '/assets/BFI_Thumb.php';
register_activation_hook( __FILE__, 'fmr_dialogs_inslall');
function fmr_dialogs_inslall() {
	global $wpdb;
	$sql = "CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."dialog` (
              `hash` varchar(32) NOT NULL COMMENT 'one-on-one dialogue message, knowing it is possible to read the dialogue',
              `user1` int(11) NOT NULL,
              `user2` int(11) NOT NULL,
              `dataadd` int(11) NOT NULL,
              `readed` tinyint(4) NOT NULL,
              `msg` text NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
	 $wpdb->query($sql);
}
global $_GET;
if (!isset($_GET['xframe'])) add_filter( 'wp_footer' , 'fmr_dialogs_addhtml' );
function fmr_dialogs_addhtml() {
	global $wpdb;
  ?>
	<div style='position:fixed;display:none' class="fmr_chat fmr_chatframe">
		<iframe style="width:100%;height:435px;outline:none;border:none;bottom:0;" id='fmr_chatframe' scrolling="no"  seamless="seamless" src=""></iframe>
			</div>
			<div class="fmr_chat_right">
			<?php
                  $lovers = $wpdb->get_results(
                  $wpdb->prepare("SELECT * FROM ".$wpdb->prefix."dialog WHERE user1 = '%d'",
                  get_current_user_id()));
				foreach ($lovers as $lover) {
						$ids[] = $lover->user2;
					}			
				$lovers = $wpdb->get_results(
                $wpdb->prepare(
                "SELECT * FROM ".$wpdb->prefix."dialog WHERE user2 = '%d' OR user1 = '%d'",get_current_user_id(),get_current_user_id()
                ));
				if ($lovers) {
					foreach ($lovers as $lover) {
						if (get_current_user_id() == $lover->user1) continue;
						if (!isset($unreaded[$lover->user1])) $unreaded[$lover->user1] = 0;
						if($lover->readed==0) $unreaded[$lover->user1]++;
						$ids[] = $lover->user1;
					}
				}
				$fmr_dialogs_userid = get_theme_mod('fmr_dialogs_userid',0);
                if($fmr_dialogs_userid!=0) { 
                    $ids[] = $fmr_dialogs_userid;
                }
				if (!isset($ids) || get_current_user_id()==0) {$ids[]=1;}
				$lovers = get_users(array("include"=>$ids));
				global $wpdb;
				foreach ($lovers as $lover) {
				if (!isset($unreaded[$lover->ID])) $unreaded[$lover->ID] = 0;
				$fmr_url = plugins_url()."/fmrDialogs/dialog_window.php";
				if (!$fmr_url) continue;
				$fmr_url .= "?user2=".(int)$lover->ID."&xframe=1";
				?>
				<div class="img_fmr_chat_item">
					<span class='unreaded'><?php echo $unreaded[$lover->ID];?></span>
					<a href="#" class="ladda-button" data-color="red" data-style2="zoom-out" data-style="zoom-out" title="<?php echo esc_html($lover->user_nicename); ?>" onclick='ladda_gochat(this,"<?php echo esc_url($fmr_url); ?>");return false'> 
						<span class="ladda-label"><?php echo get_avatar($lover->ID,60);?>
						</span>	
					</a>
				</div>
				<?php } ?>
				<div class="add_fmr_chat_item">
					<a href="<?php echo get_theme_mod('fmr_dialogs_customlink');?>">
						<div class="fmr_chat_item_circle">
							&#10010;
						</div>
					</a>
				</div>
		</div>	
  <?php
}
function fmr_chat_messages($user1, $user2)
	{
		global $wpdb;
		$msgs = $wpdb->get_results($wpdb->prepare("SELECT * FROM ".$wpdb->prefix."dialog WHERE (user1 = '%d' OR user2 = '%d') AND (user1 = '%d' OR user2 = '%d')",
			$user1, $user1, $user2, $user2));
		foreach ($msgs as $k => $v) {
			if ($v->user1 == $user1) {
	?>
					<div class="chat_message_in pull-right">
						<p class="chat_in_m">
						<?php echo wp_kses_post( convert_smilies($v->msg)); ?>
						</p>
						<div class="chat_in_m_date">
							<p class="pull-left">
							<?php echo date("d.m.Y h:i:s", esc_attr($v->dataadd))?>
							</p>
							<i class="fa fa-check"></i>
						</div>
					</div>
					<?php
			} else { ?>
					<div class="chat_message_out pull-left">
						<p class="chat_in_m">
							<?php echo esc_html( convert_smilies($v->msg)) ;?>
						</p>
						<div class="chat_in_m_date">
							<p class="pull-left"><?php echo date("d.m.Y h:i:s", esc_attr($v->dataadd))?></p>
							<i class="fa fa-check"></i>
						</div>
					</div>
					<?php
			}
	?><div class="clear"></div><?php
		}
	}
add_action('wp_head', 'fmr_dialog_add_js_vars');
 function fmr_dialog_add_js_vars()
    {
		wp_enqueue_script('fmr_chat', plugins_url( '/js/chat.js', __FILE__ ) , array('jquery'), 1, true);
		wp_enqueue_style('fmr_chatcss', plugins_url( '/css/dialogs_style.css', __FILE__ ));
		wp_enqueue_style('fmr_ladda', plugins_url( '/css/ladda.min.css', __FILE__ ));
		wp_add_inline_style('fmr_chatcss', fmr_dialog_color());
		?>
		<Script>
		var pluginsUrl = '<?php echo esc_url(plugins_url()); ?>';
		</script>
		<?php
	}
?>