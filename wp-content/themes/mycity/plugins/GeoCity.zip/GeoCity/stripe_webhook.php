<?
	
if ( !defined('ABSPATH') ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );

echo "200OK";
ob_start();

error_reporting(7);
ini_set('error_reporting', E_ALL);

ini_set('display_errors',1); 

require_once('stripe-php-2.1.2/init.php');

$stripe = array(
  "secret_key"      => get_theme_mod("premium_stripesecret","sk_test_pkdHCUuUGZaxA1Xv0C3HLo3l"),
  "publishable_key" => get_theme_mod("premium_stripepub","pk_test_hO7AvW6Ws6nDAlX8TheHP4E6")
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);

$body = @file_get_contents('php://input');
$event_json = json_decode($body);
print_R($event_json);

$serviceMessage = @$event_json->data->object->description;
$amount = @(int)$event_json->data->object->amount;
preg_match('/user#(\d+)/', $serviceMessage, $matches);
$userId = @(int)$matches[1];

echo "userID:";

if ($event_json->type == 'charge.succeeded') {
	if ($event_json->data->object->status == 'succeeded' && $event_json->data->object->currency == 'usd') {
		if ($userId) {
			mycity_balance_change((int)$userId,$amount/100,$serviceMessage);
		}
	}
}


file_put_contents("a.html",ob_get_clean());

?>