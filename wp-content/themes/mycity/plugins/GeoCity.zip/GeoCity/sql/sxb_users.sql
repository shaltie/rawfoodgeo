REPLACE INTO `6a6_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(10, 'arbuz', '$P$BNNqe1O6N1ObAB4rAmBYZvM0/EaX/W/', 'arbuz', 'arbuz@gmail.com', '', '2015-07-11 13:32:22', '', 0, 'arbuz'),
(11, 'Anna Monroe', '$P$BZ.IKnElvSI5JHkm31SiwOgA65AQg2/', 'baba-doynaya', 'Anna Monroea@gmail.com', '', '2015-07-11 13:32:49', '', 0, 'Anna Monroe'),
(12, 'bilous-victor', '$P$BV.vEP2l9nSckwaRqKwG3KCLmOJlKa.', 'bilous-victor', 'bilous-victor@gmail.com', '', '2015-07-11 13:33:09', '', 0, 'bilous-victor'),
(13, 'Elen Western', '$P$BSsDKu79gSz0w848nge3w.REiSQr2I.', 'elen-western', 'ElenWestern@gmail.com', '', '2015-07-11 13:33:30', '', 0, 'Elen Western'),
(14, 'Eric Carlberg', '$P$BxXotBpbZ/ixZNkPfqZ95Ffr9hRZwk.', 'eric-carlberg', 'EricCarlberg@gmail.com', '', '2015-07-11 13:33:59', '', 0, 'Eric Carlberg'),
(15, 'gasha', '$P$Bk03ipM9nerqxysf8nn9GKoZmYziAF1', 'gasha', 'gasha@gmail.com', '', '2015-07-11 13:36:18', '', 0, 'gasha'),
(21, 'John', '$P$BawnUqB3mfvC2kwhTi5nqh7vPZVZ6J/', 'john', 'JohnJohn@gmail.com', '', '2015-07-11 13:40:26', '', 0, 'John'),
(30, 'zalunin.alexey', '$P$BF5gbp7DxzldZZnaZs52/pEIl6lTxt/', 'zalunin-alexey', 'zalunin.alexey@gmail.com', '', '2015-07-11 13:56:23', '$P$BWXEYXPp9erBQE1ePLwLL5b34sknHA/', 0, 'zalunin.alexey'),
(32, 'Sasha', '$P$BGEWb3rH4Vm3grSss802t7Iopxg6vn1', 'sasha', '', '', '2015-07-12 19:00:56', '', 0, 'Sasha'),
(45, 'Noxon', '$P$BkCpoArmwpAnMxqv06JTAgrSxG4Xyp0', 'noxon', 'i448539@gmail.com', '', '2015-07-19 13:57:14', '', 0, 'Noxon'),
(46, 'Anettc', '$P$BTumES8ixZVDWZwjutn.pasYazwzJF.', 'anettc', 'Anettc@mail.ru', '', '2015-07-21 06:50:25', '', 0, 'Anettc'),
(47, 'amanda', '$P$BrCLR8CzWPTgU24/y.OGbTJ7YyJJkY1', 'amanda', 'amandaclark051@gmail.com', '', '2015-07-21 11:39:21', '', 0, 'amanda'),
(48, '1111111111111', '$P$BXvYkFISQ4nJ26hJ4huLFNXZV7PZrn/', '1111111111111', '', '', '2015-07-24 13:34:35', '', 0, '1111111111111');