REPLACE INTO `6a6_revslider_settings` (`id`, `general`, `params`) VALUES
(1, 'a:0:{}', '');
