REPLACE INTO `fields` (`id`, `title`, `fall`, `icon`) VALUES
(1, 'Age', 0, 'fa-signal'),
(2, 'Location', 0, 'fa-location-arrow'),
(3, 'Car', 0, 'fa-car');
