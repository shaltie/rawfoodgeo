<?php

function mycity_curl_get_contents($url)
{
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);

    $data = curl_exec($ch);
    curl_close($ch);

    return $data;
}

function mycity_my_appearance_menu_item_google()
{
    add_submenu_page('edit.php?post_type=places',
        esc_html__('import from google csv', 'mycity'),
        esc_html__('import from google csv', 'mycity'),
        'manage_categories', 'mycity_wp_importer_google2',
        'mycity_wp_importer_geocity_google');


   
}

add_action('admin_menu', 'mycity_my_appearance_menu_item_google');


function mycity_wp_importer_geocity_google()
{


    ?>

    <div class="wrap">
        <?php //var_dump(fmr_get_lat_log_from_street('Москва, м измайлово'));
        ?>

        <div>
            <h2><?php esc_html_e('Import users from CSV', 'fmr') ?>
            </h2>
            <h4><?php esc_html_e('instructions', 'fmr'); ?></h4>
            <iframe width="640" height="360" src="https://www.youtube.com/embed/OsDgiD9wK2c" frameborder="0"
                    allowfullscreen></iframe>
            <h4><?php esc_html_e('google table', 'fmr'); ?></h4>
            <p>https://docs.google.com/spreadsheets/d/1m0iXxizZif6HaYILmkM32zT-26heZpNsr8L-CTVF2Hg/edit?usp=sharing</p>

        </div>
        <?php

        if (isset($_POST['google_doc_csv']) && !empty($_POST['google_doc_csv'])):
            mycity_google_doc_import($_POST['google_doc_csv']);
            update_option('google_doc_csv', $_POST['google_doc_csv']);
        endif; ?>

        <div>
            <form method="POST" enctype="multipart/form-data" action="" accept-charset="utf-8"
                  onsubmit="return check();">
                <table class="form-table">
                    <tbody>

                    <tr class="form-field form-required">
                        <th scope="row"><label><?php esc_html_e('Google doc url', 'fmr') ?> <span
                                    class="description"></span></label></th>
                        <td>

                            <div>
                                <input class="regular-text" name="google_doc_csv" type="url"
                                       placeholder="google doc url"
                                       value="<?php
                                       $val = get_option('google_doc_csv');
                                       if (isset($val) && !empty($val)) {
                                           echo esc_url($val);
                                       } ?>"
                                >
                            </div>
                        </td>
                    </tr>


                    </tbody>
                </table>
                <input class="button-primary" type="submit" name="uploadfile" id="uploadfile_btn"
                       value="Start importing"/>
            </form>
        </div>

    </div>

    <?php
}

function mycity_google_doc_import($url_doc)
{

    $tmp_files = download_url($url_doc);
    $importedCSVFile = $tmp_files;
    $assocData = array();

    //  get arry with key from csv
    if (($handle = fopen($importedCSVFile, "r")) !== FALSE) {
        $rowCounter = 0;
        while (($rowData = fgetcsv($handle, 0, ",")) !== FALSE) {
            if (0 === $rowCounter) {
                $headerRecord = $rowData;
            } else {
                foreach ($rowData as $key => $value) {
                    $assocData[$rowCounter - 1][$headerRecord[$key]] = $value;
                }
            }
            $rowCounter++;
        }
        fclose($handle);
    }

    unlink($tmp_files);
    // var_dump($assocData);

    //import post
    global $wp_error;
    foreach ($assocData as $col) {

        if (isset($col['Title']{1})) {
            $decription = '';
            if (isset($col['Description']{1}))
                $decription = $col['Description'];

            $phone = '';
            $website = '';

            $my_post = array(
                'post_title' => sanitize_text_field($col['Title']),
                'post_content' => wp_kses_post($decription),
                'post_status' => 'publish', //change draft to publish
                'post_author' => (int)get_current_user_id(),
                'post_type' => 'places',

            );
            $id = '';


            // var_dump($my_post);
            //   var_dump($id);
            $mycity_post_ID = wp_insert_post($my_post, $wp_error);
            if (!is_wp_error($mycity_post_ID)) {
                if (isset($col["Category"]{1})) {

                    $cat_arr = explode('/', $col["Category"]);
                    $ferts_term = false;
                    if (isset($cat_arr[1])) {
                        $ferts_term = $cat_arr[0];

                        $col["Category"] = array_pop($cat_arr);
                    }
                    $term = get_term_by('name', trim($col["Category"]), 'places_categories');


                    if (isset($term->term_id)) {
                        wp_set_object_terms($mycity_post_ID, array((int)$term->term_id),
                            "places_categories");

                    } else {

                        if ($ferts_term) {
                            $parent_term = wp_insert_term(
                                $ferts_term, // the term
                                'places_categories', // the taxonomy
                                array(
                                    'description' => '',
                                    'slug' => 'places_categories',
                                    //'parent'=> $parent_term_id
                                )
                            );
                        }


                        /*     $parent_term = term_exists( 'fruits', 'product' ); // array is returned if taxonomy is given
                             $parent_term_id = $parent_term['term_id']; // get numeric term id
     */
                        if (isset($parent_term['term_id'])) {
                            $new_term = wp_insert_term(
                                $col["Category"], // the term
                                'places_categories', // the taxonomy
                                array(
                                    'description' => '',
                                    'slug' => 'places_categories',
                                    'parent' => $parent_term['term_id']
                                )
                            );
                        } else {
                            $new_term = wp_insert_term(
                                $col["Category"], // the term
                                'places_categories', // the taxonomy
                                array(
                                    'description' => '',
                                    'slug' => 'places_categories',
                                    //'parent'=> $parent_term_id
                                )
                            );
                        }

                        if (!is_wp_error($new_term)) {
                            wp_set_object_terms($mycity_post_ID, array((int)$new_term['term_id']),
                                "places_categories");

                        }


                    }

                }

                // if isset post id
                if (!is_wp_error($mycity_post_ID)) {


                    // set location
                    if (isset($col["Address"]{1})) {

                        update_post_meta($mycity_post_ID, '_adress', sanitize_text_field($col['Address']));

                        if (isset($col["lon"]{1}) && isset($col["lat"]{1})) {

                            update_post_meta($mycity_post_ID, '_myfield', sanitize_text_field($col["lat"] . ',' . $col["lon"]));

                        } else {
                            $arr_lat_long = mycity_get_lat_log_from_street($col["Address"]);
                            update_post_meta($mycity_post_ID, '_myfield', $arr_lat_long["lat"] . ',' . $arr_lat_long['lng']);

                        }

                    }
                    //set phone
                    if (isset($col['Phone']{1}))
                        update_post_meta($mycity_post_ID, '_meta_phone', sanitize_text_field($col['Phone']));
                    //set website
                    if (isset($col['Website']{1}))
                        update_post_meta($mycity_post_ID, '_meta_website', sanitize_text_field($col['Website']));

                    //set images
                    if (isset($col['img_max_url']{1})) {
                        $data = mycity_upload_img_from_url(esc_url($col['img_max_url']));
                        if (!is_wp_error($data)) {
                            update_post_meta($mycity_post_ID, '_big_img', $data->attachment_id);
                        }
                    }
                    if (isset($col['img_min_url']{1})) {
                        $data = mycity_upload_img_from_url(esc_url($col['img_min_url']));
                        if (!is_wp_error($data)) {
                            update_post_meta($mycity_post_ID, '_small_img', $data->attachment_id);
                        }
                    }

                    //set short_description
                    if (isset($col['short_description']{1})) {
                        update_post_meta($mycity_post_ID, 'smalldescr', wp_kses_post($col['short_description']));
                    }
                    //set instagram
                    if (isset($col['Instagram_checkpoint']{1})) {
                        update_post_meta($mycity_post_ID, 'instaid', wp_kses_post($col['Instagram_checkpoint']));
                    }


                    //post_inside
                    if (isset($col['inside_view']{1})) {
                        update_post_meta($mycity_post_ID, 'post_inside', $col['inside_view']);
                    }
                    //post_post_street_view
                    if (isset($col['street_view']{1})) {
                        update_post_meta($mycity_post_ID, 'post_street_view', $col['street_view']);
                    }

                    //***********************OFERS *****************/
                    if (isset($col['OFFER_Title']{1})) {
                        update_post_meta($mycity_post_ID, 'coupontitle', esc_html($col['OFFER_Title']));
                    }

                    // set coupondescr
                    if (isset($col['OFFER_Description ']{1})) {
                        update_post_meta($mycity_post_ID, 'coupondescr', $col['OFFER_Description']);
                    }
                    // set Coupon_code
                    if (isset($col['Coupon_code']{1})) {
                        update_post_meta($mycity_post_ID, 'coupons', $col['Coupon_code']);
                    }
                    // set tegs
                    if (isset($col['Tags']{1})) {
                        update_post_meta($mycity_post_ID, '_tags', $col['Tags']);
                    }


                }
                ?>
                <div class="updated below-h2 rs-update-notice-wrap">

                    <p><?php echo esc_html__("Places added ", 'mycity') . sanitize_text_field($col['Title']); ?></p>
                </div>
                <?php

            }


        }
    }


    ?>
    <div class="updated below-h2 rs-update-notice-wrap" id="message">

        <p><?php esc_html_e("Import places has been successfully", 'fmr'); ?> </p></div>

    <?php


}


/**
 * @param $street
 * @return array lat lng from street
 */
function mycity_get_lat_log_from_street($street)
{
    flush();
    $url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode($street) . '&key=AIzaSyCvVdf_j1dZYDB5Ympn_ar-mokcgWcAC0U';
    $res = wp_remote_get($url);
    $arr_locations = @json_decode(($res['body']));
    //lat , lng
    $lat_long = array('lat' => '0', 'lng' => '0');
    if (isset($arr_locations->results[0]->geometry->location)) {
        $lat_long['lat'] = $arr_locations->results[0]->geometry->location->lat;
        $lat_long['lng'] = $arr_locations->results[0]->geometry->location->lng;
    }
    return $lat_long;

}

function mycity_upload_img_from_url($file)
{
    $data = new stdClass();

    if (!function_exists('media_handle_sideload')) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
    }
    if (!empty($file)) {

        // Set variables for storage, fix file filename for query strings.
        preg_match('/[^\?]+\.(jpe?g|jpe|gif|png)\b/i', $file, $matches);
        $file_array = array();
        $file_array['name'] = basename($matches[0]);

        // Download file to temp location.
        $file_array['tmp_name'] = download_url($file);

        // If error storing temporarily, return the error.
        if (is_wp_error($file_array['tmp_name'])) {
            return $file_array['tmp_name'];
        }

        // Do the validation and storage stuff.
        $id = media_handle_sideload($file_array, 0);

        // If error storing permanently, unlink.
        if (is_wp_error($id)) {
            @unlink($file_array['tmp_name']);
            return $id;
        }

        // Build the object to return.
        $meta = wp_get_attachment_metadata($id);
        $data->attachment_id = $id;
        $data->url = wp_get_attachment_url($id);
        $data->thumbnail_url = wp_get_attachment_thumb_url($id);
        $data->height = $meta['height'];
        $data->width = $meta['width'];
    }

    return $data;
}