<?php
/*
Plugin Name: GeoCity
Plugin URI: 
Description:
Version: 2.9
Author: Victor Lerner
Author URI: 
License: 
*/


/**********************************************************/
register_activation_hook(__FILE__, 'mycity_mycity_inslall');


/**
 *Create the desired tables for theme
 */
function mycity_mycity_inslall()
{
    global $wpdb;

    $sql = "CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "transactions` (
              `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
              `data` int(11) NOT NULL,
              `json` text NOT NULL,
              `descr` varchar(300) NOT NULL,
              `user` int(11) NOT NULL,
              `summ` double NOT NULL,
			  `balance1` double NOT NULL,
			  `balance2` double NOT NULL,
              `status` varchar(255) DEFAULT NULL,
			  PRIMARY KEY (`id`)
			  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
    $q = mycity_q($sql);

    $sql = "CREATE TABLE IF NOT EXISTS `stripe2` (
              `id` int(11) NOT NULL,
              `data` int(11) NOT NULL,
              `json` text NOT NULL,
              `descr` varchar(300) NOT NULL,
              `user` int(11) NOT NULL,
              `summ` double NOT NULL,
              `status` varchar(255) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
    $q = mycity_q($sql);

    $sql = "CREATE TABLE IF NOT EXISTS `follow` (
              `user1` int(11) NOT NULL,
              `user2` int(11) NOT NULL,
              `dataadd` int(11) NOT NULL,
              KEY `user1` (`user1`),
              KEY `user2` (`user2`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
    $q = mycity_q($sql);

}

function mycity_q($sql)
{
    global $wpdb;
    $wpdb->hide_errors();
    return $wpdb->query($sql);
}


require plugin_dir_path(__FILE__) . '/import_demo.php';
require plugin_dir_path(__FILE__) . '/mycity_osm.php';
require plugin_dir_path(__FILE__) . '/import_places_from_google.php';
require plugin_dir_path(__FILE__) . '/import_google_places.php';
//require plugin_dir_path( __FILE__ ). '/tgm.php';
// additional functions
add_shortcode('airbnb', 'mycity_airbnb_parse');
/**
 * Add the shortcode [airbnb] and parse for url
 *
 * @param $atts
 * @return string
 */
function mycity_airbnb_parse($atts)
{
    if (empty($wp_filesystem)) {
        require_once(ABSPATH . '/wp-admin/includes/file.php');
        WP_Filesystem();
    }
    $url = get_theme_mod('airbnb_url');
    if (strlen($url) < 20) {
        return;
        exit();
    }

    $aribbn_date = get_transient('mycity_aribbn_shortcode');
    if (false === $aribbn_date ) {


        $res = wp_remote_get($url);
        $saw = new mycity_nokogiri($res['body']);
        $res2 = wp_remote_get('https://ru.airbnb.com/rooms/11294794');
        $saw2 = new mycity_nokogiri($res['body']);
        $arr_pars = $saw->get('div.listings-container div.col-sm-12 .panel-overlay-top-right')->
        toArray();
        $arr_price = $saw->get('div.listings-container div.col-sm-12  .price-label')->
        toArray();
        $price=  $saw->get('div.listings-container div.col-sm-12  .price-amount')->toArray();
       // var_dump($price);
        $i = 0;
        ob_start();
        if ($arr_pars) {
            foreach ($arr_pars as $item) {


                ?>
                <div style="min-height: 250px; margin-bottom: 20px;" class="col-md-4 col-sm-4 col-xs-12">
                    <div style="height: 120px; margin-bottom: 20px;">
                        <?php
                                        echo "<b>" . $item['span']['data-name'] . "</b><br>";
                        echo esc_html__('Price: ', 'mycity') .  $arr_price[$i]['sup'][0]['#text'] .  ' ' .  $arr_price[$i]['span'][0]['#text'] ."<br>";
                        echo esc_html__('Rating: ', 'mycity') . $item['span']['data-star_rating'] . "<br>";
                        ?>
                        <?php
                        if (strlen(get_theme_mod('airbnb_referal')) > 8): ?>
                            <a href="<?php
                            echo esc_url(get_theme_mod('airbnb_referal'));
                            ?>"><?php echo esc_html__("Booking", "mycity"); ?></a>
                        <?php endif; ?>
                    </div>
                    <div style="height: 150px; width: 100%; overflow:hidden ;">
                        <img src="<?php echo $item['span']['data-img']; ?>" width="100%"/>
                    </div>
                </div>
                <?php
                $i++;
            }
        }
        ?>
        <div style="clear: both;"></div>
        <?php
        $date = ob_get_clean();
        //set_transient('mycity_aribbn_shortcode', $date, 60 * 60);
        return $date;
    }
    return get_transient('mycity_aribbn_shortcode');
}


add_action('init', 'mycity_Places_init', 0);

function mycity_Places_init()
{


    $args = array(
        'labels' => array(
            'edit_item' => __('Edit'),
            'add_new_item' => __('Add'),
            'view_item' => __('View'),
        ),
        'public' => true,
        'show_ui' => true,
        '_builtin' => false,
        '_edit_link' => 'post.php?post=%d',
        'capability_type' => 'post',
        'hierarchical' => false,
        'has_archive' => true,
        'show_in_nav_menus ' => true,
        'rewrite' => array("slug" => "places"), // формат ссылок
        'supports' => array('title', 'editor', 'thumbnail','sticky')
    );

    $args['label'] = esc_html__('Places', "mycity");
    $args['singular_label'] = esc_html__('Place', "mycity");
    register_post_type('places', $args);

    register_taxonomy(
        'places_categories',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'places',         //post type name
        array(
            'hierarchical' => true,
            'label' => esc_html__("Places category", "mycity"),  //Display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'place', // This controls the base slug that will display before each term
                'with_front' => false // Don't display the category base before
            )
        )
    );

    global $_POST, $_GET, $_FILES;

    if (isset($_POST['taxonomy']) && $_POST['taxonomy'] == 'places_categories') {

        $fileicon = ABSPATH . '/wp-content/uploads/' . (int)$_POST['tag_ID'] . '.png';
        if (strlen($_FILES['fa_icon_image']['tmp_name']) > 4) {
            //print_R($_FILES);
            move_uploaded_file($_FILES['fa_icon_image']['tmp_name'], $fileicon);
            //die();
        } else if ($_POST['fa_icon'] && preg_match('#fa#', $_POST['fa_icon'])) {

            $iconname = str_replace("fa-", "", $_POST['fa_icon']);
            //Create color marker
            $image = imagecreatefrompng(get_template_directory() . '/img/marker_blank.png');
            $icon = imagecreatefrompng(get_template_directory() . '/font/16/' . $iconname . '.png');
            imagesavealpha($image, 1);
            imagealphablending($image, false);
            imagesavealpha($icon, 1);
            imagealphablending($icon, false);

            $color = str_replace('#', '', $_POST['fa_color']);
            if (strlen($color) != 6) {
                $mycity_rgb = array(0, 0, 0);
            }
            $mycity_rgb = array();
            for ($x = 0; $x < 3; $x++) {
                $rgb[$x] = hexdec(substr($color, (2 * $x), 2));
            }

            mycity_imageReplaceColor($image, $rgb);
            mycity_imagecopymerge_alpha($image, $icon, 6, 6, 0, 0, 256, 256, 100);
            if (!$_POST['tag_ID']) $_POST['tag_ID'] = 0;
            imagepng($image, $fileicon);

        }
        if ($_POST['action'] == 'add-tag') {
            register_shutdown_function("mycity_savefa2cat");
        } else {
            update_option("fa_icon_" . (int)$_POST['tag_ID'], sanitize_text_field($_POST['fa_icon']));
            update_option("fa_color_" . (int)$_POST['tag_ID'], sanitize_text_field($_POST['fa_color']));
        }
    }


}

function mycity_send_sms($to, $message)
{

    $test = "0";
    $username = get_option("sms_api_emeail");
    $hash = get_option("sms_api_hash");
    $sender = "API Test"; // This is who the message appears to be from.
    $numbers = $to; // A single number or a comma-seperated list of numbers
    $message = urlencode($message);
    $data = "username=" . $username . "&hash=" . $hash . "&message=" . $message . "&sender=" . $sender . "&numbers=" . $numbers . "&test=" . $test;

    $ch = curl_init('http://api.txtlocal.com/send/?');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch); // This is the result from the API
    curl_close($ch);
    return $data . ":" . $result;
}

function mycity_sendRequestCurl($command, $params)
{
    $url = $command . '/';
    // Initialize handle
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 3
    ));
    $rawResponse = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($rawResponse === false) {
        throw new Exception('Failed to connect to the Textlocal service: ' . $error);
    } elseif ($httpCode != 200) {
        throw new Exception('Bad response from the Textlocal service: HTTP code ' . $httpCode);
    }
    return $rawResponse;
}


add_action('admin_menu', 'mycity_android_admin_menu');
function mycity_android_admin_menu()
{
    add_menu_page('Page title', esc_html__('Mobile App', "mycity"), 'manage_options', 'mycorodva-handle', 'mycity_android_admin', get_template_directory_uri() . "/img/apkicon.png");
}

function mycity_android_admin()
{
    global $_POST;

    if (!get_option('cordova_config')) {
        add_option('cordova_config', esc_html__('Your App name', "mycity"));
    }

    if (isset($_POST['cordova_config']) && $_POST['cordova_config']) {
        update_option('cordova_config', str_replace("\\", "", $_POST['cordova_config']));
    }


    if (isset($_FILES['file']) && $_FILES['file']) {
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        $uploadedfile = $_FILES['file'];

        $upload_overrides = array('test_form' => false);

        $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

        if ($movefile && !isset($movefile['error'])) {
            update_option("cordova_img", $movefile['url']);
        } else {
            /**
             * Error generated by _wp_handle_upload()
             * @see _wp_handle_upload() in wp-admin/includes/file.php
             */
            echo esc_html($movefile['error']);
        }
    }

    ?>


    <div class='wrapper notice'><h1>Native app can be build and upload to AppStore and Google play by our team</h1>
        We can build native iOS app for you and send it to AppStore. You need only icon and 100$.

        <h2>See demo</h2>
        <img
            src='https://lh3.googleusercontent.com/ATBYvHjY38m5If_pMd5hAMStEQR3JyuLY9wMHiIzhwhfIfjOpijs2cw80beYBhEBBUc=h310-rw'>
        <img
            src='https://lh3.googleusercontent.com/CyV2XI-2vg8h-sWtRBPVege3x3lyNIGuPdqpcf1KPV_ZJ1bdPLz-_Ooc_BLEhYXzEkw=h310-rw'>
        <img
            src='https://lh3.googleusercontent.com/sRSVJjmlqYFDLTE8E_HvLU7tk7VwycByC7eVSMeEVh2JdRfT-J2Az_oeBNrA4ufbahE=h310-rw'>
        <br><br>
        <a target="_blank"
           href="https://play.google.com/store/apps/details?id=com.fdc.freedeveloperscommunity.mycity"><img height='40'
                                                                                                            src='https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png'></a>
        <a target="_blank" href="https://itunes.apple.com/us/app/my-city/id1107174056?ls=1&mt=8"><img height='40'
                                                                                                      src='http://1343542019.rsc.cdn77.org/wp-content/uploads/2012/05/app-store1.png'></a>

        <h2>Your benefits</h2>
        <li>You not need iOS and Android dev skills</li>
        <li>You not need Apple developer liecence (Save 99$!)</li>
        <li>Guaranted approve.</li>
        <li>App have live connection to your site.</li>
        <li>All updates free!</li>
        <Hr>
        <h2>Process</h2>
        <form action='' class='wrapper' method='post' enctype='multipart/form-data'>
            Icon: <br><br>
            1. Create icon for your app. Or use free icon from http://www.iconarchive.com/ or http://iconfinder.com
            (only PNG, square!)<Br>
            2. Upload it to this form: <Br>

            <input type='file' name='file' value='' class='btn btn-primary'><br>
            <?php
            $img = esc_url(get_option("cordova_img"));

            if ($img) {

                echo '<img style="max-height:120px" src="' . $img . '">';
                echo "<Br>Your icon url: " . $img . "";
            }


            ?>


            <Br>Name: <Br>
            <input type='text' name='cordova_config' value='<?= get_option("cordova_config"); ?>' class='form-control'>
            <br>

            <input type='submit' class='btn btn-primary' value='Save name & icon'>
            <br>
            3. Contact me in skype: noxon.su <br>
            4. Whait 1-2 days, and enjoy your app!
        </form>

    </div>
    <Br><br>

    <div class='wrapper notice'><h1>Cordova project</h1>
        <a href='<?= get_template_directory_uri(); ?>/cordovaTemplate.zip'>Download apache cordova template</a>
        See more information at <a
            href='https://cordova.apache.org/docs/en/5.0.0/guide_platforms_ios_index.md.html#iOS%20Platform%20Guide'>https://cordova.apache.org/docs/en/5.0.0/guide_platforms_ios_index.md.html#iOS%20Platform%20Guide</a>
        <br><br>
        We are not provide support for Cordova project. We provide only cordovatemplate of our theme. <br>
    </div>
    <?php
}

/**
 *
 */
function mycity_savefa2cat()
{
    global $_POST;
    $categories = get_categories("taxonomy=places_categories&hide_empty=0&orderby=ID&order=DESC");
    update_option("fa_icon_" . $categories[0]->term_id, sanitize_text_field($_POST['fa_icon']));
    update_option("fa_color_" . $categories[0]->term_id, sanitize_text_field($_POST['fa_color']));
    rename(ABSPATH . '/wp-content/uploads/0.png', ABSPATH . '/wp-content/uploads/' .
        $categories[0]->term_id . '.png');
}


function fmr_whait()
{
    ?>

    <div style="
                  position: fixed;
                  z-index: 1000;
                  top: 0;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  background: rgba(255,255,255,0.8);">

        <div id="paymentWaitDisplay" style="
                      border-radius: 5px;
                      padding: 40px;
                      background: #FFF;
                      font: 25px 'Lato-Light', sans-serif;
                      width: 80%;
                      margin: auto;
                      height: 50%;
                      text-align: center;
                      position: absolute;
                      top: 0;
                      bottom: 0;
                      left: 0;
                      right: 0;
                      box-shadow: 0 0 13px rgba(0,0,0,0.3);
                  ">
            <?php esc_html_e('Wait for payment system response...', 'mycity'); ?>
        </div>

    </div>


    <script>
        var TIMEOUT_MAX = 5 * 60 * 1000; // 5 mins
        var CHECK_TIMEOUT = 15 * 1000; //10 secs
        var CHECK_URL = '/';

        var serviceMessage = '<?php echo $serviceMessage?>';
        var isWaiting = true;
        var checkerInterval = null;


        function stopWaiting() {
            isWaiting = false;
            clearInterval(checkerInterval);
        }

        checkerInterval = setInterval(function () {

            jQuery.post(CHECK_URL, {descr: serviceMessage}, function (data) {
                stopWaiting();
            }).done(function () {
                    jQuery('#paymentWaitDisplay').html('Payment success');
                    window.location = window.location.href;
                })
                .fail(function () {
                    jQuery('#paymentWaitDisplay').html('There was an error during the payment');
                    //location.href = '/?p=balance&payment_status=0';
                });

        }, CHECK_TIMEOUT);

        setTimeout(function () {
            stopWaiting();
            jQuery('#paymentWaitDisplay').html('There was an error during the payment');
            location.href = '/?p=balance&payment_status=0';
        }, TIMEOUT_MAX);

    </script>

    <?php
}


function stripe_form($price, $userid)
{
    global $_POST;

    if (isset($_POST['stripeToken'])) {

        require_once plugin_dir_path(__FILE__) . 'stripe-php-2.1.2/init.php';

        // Set your secret key: remember to change this to your live secret key in production
        // See your keys here https://dashboard.stripe.com/account/apikeys
        \Stripe\Stripe::setApiKey(get_theme_mod("premium_stripesecret", "sk_test_pkdHCUuUGZaxA1Xv0C3HLo3l"));

        // Get the credit card details submitted by the form
        $token = $_POST['stripeToken'];
        $transactionHash = dechex(rand(10000000000000, 100000000000000));
        $serviceMessage = $transactionHash . " increase balance user#" . $userid;

        // Create the charge on Stripe's servers - this will charge the user's card
        try {
            $charge = \Stripe\Charge::create(array(
                    "amount" => $_POST['price'], // amount in cents, again
                    "currency" => "usd",
                    "source" => $token,
                    "description" => $serviceMessage)
            );

            fmr_whait();

        } catch (Exception $e) {
            // The card has been declined
            print_R($e);
        }
    }

    ?>
    <a name="b"></a>
    <form action="" method="POST">
        <input type="hidden" name="price" value="<?php echo $price ?>00"/>

        <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="<?php echo get_theme_mod("premium_stripepub", "pk_test_hO7AvW6Ws6nDAlX8TheHP4E6"); ?>"
            data-image="//stripe.com/img/documentation/checkout/marketplace.png"
            data-name="<?php echo $_SERVER['HTTP_HOST'] ?>"
            data-description="increase balance user#<?php echo $userid; ?>"
            data-amount="<?php echo $price ?>00">
        </script>

    </form>
    <?php
}

function mycity_balance_change($user_id, $summ, $descr)
{
    global $wpdb;
    $summ = (double)$summ;
    $cur = (double)get_user_meta($user_id, "balance", true);
    $wpdb->query($wpdb->prepare("INSERT INTO " . $wpdb->prefix . "transactions SET
	balance1 = '" . $cur . "',
		status = '1',
		descr='" . esc_html($descr) . "',
		data = '" . time() . "',
		summ = '" . $summ . "',
		user = '%s'
		", $user_id));

    $tid = $wpdb->insert_id;
    $newal = $cur += $summ;
    update_user_meta($user_id, "balance", $newal);

    $wpdb->query("UPDATE " . $wpdb->prefix . "transactions SET balance2='" . (double)get_user_meta($user_id, "balance", true) . "' WHERE id = '$tid'");
    return $newal;
}


?>