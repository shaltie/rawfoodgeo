<?

if ( !defined('ABSPATH') ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
try {

    if (!isset($_POST['descr'])) {
        die(http_response_code(502));
    };
	
	http_response_code(200);
    
} catch (Exception $e){
    die(http_response_code(500));
}

ob_get_clean();
?>