<?php

function mycity_my_appearance_menu_item()
{
    add_theme_page(__('Import demo data', 'mycity'), __('Import demo data',
        'mycity'), 'edit_theme_options', 'mycity_wp_importer_geocity244',
        'mycity_wp_importer_geocity');
}

add_action('admin_menu', 'mycity_my_appearance_menu_item');


function mycity_wp_importer_geocity()
{
    global $_POST;
    if (isset($_POST['wfm_hidenn']) && $_POST['wfm_hidenn'] == 'wmf_hiden') {


        global $wpdb, $wp_filesystem;

        /*
         * uploads files
         */
        if (empty($wp_filesystem)) {
            require_once(ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }

        //dowload files
        $tmp_files = download_url('http://city1.wpmix.net/2016_v3.zip');

        if (is_wp_error($tmp_files)) {
            $tmp_files->get_error_messages();

        } else {
            $destination = wp_upload_dir();
            unzip_file($tmp_files, $destination['basedir']);
        }
        /*
         * SQL
         */

        global $wpdb;
        //$wpdb->show_errors();
        $wpdb->hide_errors();
        $users_role = get_option('user_roles');
        $admin_email = get_option('admin_email');
        /*********************************************************************************/
        $filename = plugin_dir_path(__FILE__) . 'sql/vioo_wp.sql';

        ($fp = fopen($filename, 'r'));
        $wpdb->hide_errors();
        $query = '';

        while ($line = fgets($fp, 1024000)) {
            if (substr($line, 0, 2) == '--' OR trim($line) == '') {
                continue;
            }
            $query .= mb_convert_encoding($line, "UTF-8");
            $query = str_replace(array('wp2_', 'http://city5.vioo.ru', 'admin@mycity3.vioo.ru'), array($wpdb->prefix, get_home_url('/'), $admin_email), $query);
            if (substr(trim($query), -1) == ';') {
                if (!$wpdb->query($query)) {
                }
                $query = '';
            }
        }


        update_option('user_roles', $users_role);
        update_option('admin_email', $admin_email);
        update_option('page_on_front', 372);
        update_option('show_on_front', 'page');


        ?>
        <div class="updated below-h2 rs-update-notice-wrap" id="message">

            <p>
                <?php
                _e('Import was successful. ReActivate all plugins!', 'mycity')
                ?>
            </p></div>
        <?php
    }
    ?>
    <div style="padding:20px;background-color:white;

        margin-bottom: 2px;
margin-left: 15px;
margin-right: 15px;
margin-top: 5px;
        ">
        <?php
        _e('Press the button for import', 'mycity')
        ?>

        <form action="" method="post">
            <table border="0" width="600">

                <input type="hidden" name="wfm_hidenn" value="wmf_hiden"/>
                <tbody>

                <tr> <?php


                    ?>
                    <span style="color: red; font-weight: bold"> All exist data will be deleted!</span>
                    <td colspan="2"><input type="submit" class='btn btn-primary primary' value="Import"/></td>
                </tr>
                </tbody>
            </table>
        </form>
    </div>
    <?php
}

?>