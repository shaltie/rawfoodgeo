<?php


function curl_get_contents($url)
{
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);

    $data = curl_exec($ch);
    curl_close($ch);

    return $data;
}

function mycity_my_appearance_menu_item_osm()
{
    add_submenu_page('edit.php?post_type=places',
        esc_html__('import from open street map', 'mycity'),
        esc_html__('import from open street map', 'mycity'),
        'manage_options', 'mycity_wp_importer_osm2',
        'mycity_wp_importer_geocity_osm');


}

add_action('admin_menu', 'mycity_my_appearance_menu_item_osm');


function mycity_wp_importer_geocity_osm()
{
    ?>
    <div style="padding:20px;background-color:white;

        margin-bottom: 2px;
margin-left: 15px;
margin-right: 15px;
margin-top: 5px;
        ">
        <?php

        _e('Press the button for import', 'mycity');


        global $wp_filesystem;
        if (empty($wp_filesystem)) {
            require_once(ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }

        if (isset($_POST['place_category']) and !empty($_POST['place_category'])) {
            $_SESSION['place_category'] = $_POST['place_category'];
        }
        ?>


        <form action="" method="post" class="">

            <div class="form-group">
                <h3><?php esc_html_e('Video instruction', 'mycity'); ?>
                </h3>
                <?php echo do_shortcode('[video src="https://youtu.be/KveP_-Dxs6Y"]'); ?>
            </div>
            <div class="osm_form">
                <input type="hidden" name="wfm_hidenn" value="wmf_hiden"/>

                <div class="form-group">
                    <label for="location_s"><?php esc_html_e('Select your city', 'mycity'); ?>  </label>
                    <input name="city" id="location_s" type="text" class="typeahead form-control" value="">
                </div>
                <div class="form-group">
                    <label for="location_amenity"><?php esc_html_e('Select your amenity', 'mycity'); ?>  </label>
                    <input name="amenity" id="location_amenity" type="text" class="typeahead2 form-control" value="">
                </div>
                <div class="form-group">
                    <label for="category"><?php esc_html_e('Select your Places category', 'mycity'); ?>  </label>
                    <?php
                    $cats = get_categories("taxonomy=places_categories");
                    ?>
                    <select name='place_category' id='category' class="selectpicker form-control">
                        <option value="-1">——–</option>
                        <?php
                        $cat_get = (isset($_SESSION['place_category'])) ? (int)$_SESSION['place_category'] : "";
                        foreach ($cats as $cat) {
                            ?>
                            <option
                                value='<?php echo (int)$cat->cat_ID ?>' <?php if ((int)$cat->cat_ID == $cat_get) echo 'selected="selected"'; ?>><?php echo esc_html($cat->name); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <?php

            if (isset($_POST) and !empty($_POST)) {
            global $wp_error;

            //import selected post
            if (isset($_POST['post'][0])) {

                foreach ($_POST['post'] as $item) {

                    $element = json_decode(base64_decode($item));
                    $an_array = (array)$element->tags;
                    $decription = '';
                    if (isset($element->description{1})) {
                        $decription .= $element->description;
                    } elseif (isset($an_array['wheelchair:description'])) {
                        $decription .= $an_array['wheelchair:description'];
                    }
                    $phone = '';
                    $website = '';
                    foreach ($an_array as $k => $v) {
                        if ($k == 'contact:phone' || $k == 'phone') {
                            $phone = $v;
                            continue;
                        }
                        if ($k == 'contact:website' || $k == 'website') {
                            $website = $v;
                            continue;
                        }
                        if ($k == 'wheelchair:description' || $k == 'name' || $k == 'amenity') {
                            continue;
                        }
                        if (preg_match('#addr#', $k) || preg_match('#name#', $k)) {
                            continue;
                        }

                        $k = str_replace(':', ' ', $k);
                        $k = str_replace('_', ' ', $k);
                        $decription .= '[feature]' . sanitize_text_field($k) . ':' . sanitize_text_field($v) . ' [/feature]';

                    }
                    sanitize_text_field($element->tags->name);

                    $my_post = array(
                        'post_title' => sanitize_text_field($element->tags->name),
                        'post_content' => wp_kses_post($decription),
                        'post_status' => 'publish', //change draft to publish
                        'post_author' => (int)get_current_user_id(),
                        'post_type' => 'places',

                    );

                    /**
                     * if the user is not authorized, we will send it to the login page.
                     */

                    $mycity_post_ID = wp_insert_post($my_post, $wp_error);


                    if (!is_wp_error($mycity_post_ID)) {
                        wp_set_object_terms($mycity_post_ID, array((int)$_POST['place_category']),
                            "places_categories");
                        update_post_meta($mycity_post_ID, '_myfield', $element->lat . ',' . $element->lon);
                        update_post_meta($mycity_post_ID, '_adress', mycity_osm_get_street_from_lat_lng($element->lat . ',' . $element->lon));
                        update_post_meta($mycity_post_ID, '_meta_phone', sanitize_text_field($phone));
                        update_post_meta($mycity_post_ID, '_meta_website', sanitize_text_field($website));


                    }
                    echo esc_html("Places added ", 'mycity') . sanitize_text_field($element->tags->name);

                    echo "\n<br/><br/>";

                }


            }
            // get nodes by city and cats
            if (isset($_POST['city']{2})) {
                $city = sanitize_text_field($_POST['city']);
                $amenity = sanitize_text_field($_POST['amenity']);
                $query = 'http://overpass-api.de/api/interpreter?data=[out:json];area[name="' . $city . '"]; node(area)[amenity=' . $amenity . ']; out;';
                // great valid url
                $query = str_replace(' ', '%20', $query);
                $node_xml = curl_get_contents($query);
                $res = json_decode($node_xml);
            }


            ?>
            <table class="wp-list-table widefat fixed striped pages">
                <thead>
                <?php if (isset($res->elements)) { ?>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text"
                                                                                        for="cb-select-all-1">Select
                                All</label><input id="cb-select-all-1" type="checkbox"></td>

                    </tr>
                <?php } ?>
                </thead>

                <tbody id="the-list">

                <?php if (isset($res->elements)) {
                    $i = 1;
                    foreach ($res->elements as $element) {
                        $an_array = (array)$element->tags;
                        if (isset($element->tags->name) /*&& isset($an_array['addr:city'])*/) { ?>
                            <tr id="post-<?php echo esc_html($element->id); ?>"
                                class="iedit author-self level-0 post-<?php echo esc_html($element->id); ?> type-page status-publish hentry">
                                <th scope="row" class="check-column">
                                    <label class="screen-reader-text"
                                           for="cb-select-<?php echo esc_html($element->id); ?>">Select
                                        chat</label>
                                    <input id="cb-select-<?php echo esc_html($element->id); ?>" type="checkbox"
                                           name="post[]" value='<?php

                                    echo base64_encode(json_encode($element));

                                    ?>'>
                                    <div class="locked-indicator"></div>
                                </th>
                                <td class="title column-title has-row-actions column-primary page-title"
                                    data-colname="Title">
                                    <label
                                        for="cb-select-<?php echo esc_html($element->id); ?>">
                                        <?php echo wp_kses_post($i . ') <b>' . $element->tags->name . '</b>');
                                        ?>
                                    </label>
                                </td>
                                <td class="author column-author"
                                    data-colname="Author">
                                    <?php //var_dump($element);

                                    /*$an_array = (array) $element->tags;
                                    var_dump($an_array);*/
                                    //var_dump($element);
                                    foreach ($element->tags as $k => $v) {
                                        echo wp_kses_post($k . ' => ' . $v) . '<br/>';
                                    }

                                    ?>
                                </td>
                            </tr>

                            <?php

                            ++$i;
                        }

                    }
                }

                }


                ?>

                </tbody>


            </table>
            <?php
            if (isset($_POST['city']{2})) {
                submit_button(esc_html__("Start import", 'mycity'));

            } else {
                submit_button(esc_html__("Get nodes", 'mycity'));
            }
            `` ?>
        </form>
    </div>
    <script>

        jQuery(document).ready(function ($) {

            $('.typeahead').typeahead({
                source: mycity_osm_obj.location

            });
            $('.typeahead2').typeahead({
                source: mycity_osm_obj.amenity

            });
        });
    </script>
    <?php
}


/*
 * ыскшзеы оы
 */

function mycity_osm_enqueue($hook)
{
   /* if ('appearance_page_mycity_wp_importer_osm' != $hook) {
        return;
    }*/


    global $wp_filesystem;
    if (empty($wp_filesystem)) {
        require_once(ABSPATH . '/wp-admin/includes/file.php');
        WP_Filesystem();
    }

    $con = $wp_filesystem->get_contents(plugin_dir_path(__FILE__) . "/interpreter.json");
    $amenity = $wp_filesystem->get_contents(plugin_dir_path(__FILE__) . "/amenity.json");

    wp_enqueue_style('mycity_2bootstrap', plugin_dir_url(__FILE__) .
        "/css/style.css");

    wp_enqueue_script('mycity_osm_bootstrap3_typeahead2', plugin_dir_url(__FILE__) .
        '/js/bootstrap3-typeahead.min.js', array('jquery'));



    wp_localize_script('mycity_osm_bootstrap3_typeahead2', 'mycity_osm_obj',
        array(

            'location' => json_decode($con),
            'amenity' => json_decode($amenity),

        ));
}

add_action('admin_enqueue_scripts', 'mycity_osm_enqueue');
/**
 * @param $street
 * @return array lat lng from street
 */
function mycity_osm_get_street_from_lat_lng($street)
{
    flush();
    //https://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&key=YOUR_API_KEY

    $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . urlencode($street) . '&key=AIzaSyCvVdf_j1dZYDB5Ympn_ar-mokcgWcAC0U';
    $body = wp_remote_get($url);
    $arr_locations = @json_decode($body['body']);
    if (isset($arr_locations->results[0]->formatted_address)) {
        return ($arr_locations->results[0]->formatted_address);
    } else {
        return false;
    }

}

