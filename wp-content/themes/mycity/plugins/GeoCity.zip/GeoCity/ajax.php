<?php 
	
if ( !defined('ABSPATH') ) {
/** Set up WordPress environment */
require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

	
if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
if (isset($_GET['like'])) {
	$likes = get_option("term_likes_".(int)$_GET['like'],(int)$_GET['id']);
	update_option("term_likes_".(int)$_GET['like'],$likes++);
}
if (isset($_GET['update_post_view'])) {
	$views = (int)get_option("views_".(int)$_GET['update_post_view']);
	$views++;
	update_option("views_".(int)$_GET['update_post_view'],$views);
	echo esc_html($views);
}
if (isset($_GET['cordovaget'])) {
	echo get_option("cordova_img").";";
	echo get_option("cordova_config");
}
if (isset($_GET['msg_send'])) {
	$wpdb->insert( 
		'dialog', 
		array( 
			'user1' => get_current_user_id(), 
			'user2' => (int)$_GET['msg_send'],
			'dataadd' => time(),
			'msg' => esc_textarea ( $_POST['msg'] )
		), 
		array( 
			'%d', 
			'%d',
			'%d',
			'%s'
		) 
	);
	mycity_chat_messages(get_current_user_id(),esc_textarea($_GET['msg_send']));
}
if (isset($_GET['msg_get'])) {
	$id = get_current_user_id();
	mycity_chat_messages($id,esc_textarea($_GET['msg_get']));
	
} 
if (isset($_GET['togglefollow'])) {
	if (mycity_is_follow(get_current_user_id(), (int)$_GET['togglefollow'])) {
		//unfollow
		$wpdb->query(
			"
			DELETE FROM follow 
			WHERE user1 = '".get_current_user_id()."' AND user2 = '".(int)$_GET['togglefollow']."'
			"
		);
		echo esc_html__("Follow","mycity");;
		
	} else {
		//
		$wpdb->insert( 
			'follow', 
			array( 
				'user1' => get_current_user_id(), 
				'user2' => (int)$_GET['togglefollow'],
				'dataadd' => time(),
			), 
			array( 
				'%d', 
				'%d',
				'%d'
			) 
		);
		$wpdb->insert( 
			'dialog', 
			array( 
				'user1' => get_current_user_id(), 
				'user2' => (int)$_GET['togglefollow'],
				'dataadd' => time(),
				'msg' => ":)"
			), 
			array( 
				'%d', 
				'%d',
				'%d',
				'%s'
			) 
		);
		echo esc_html__("Unfollow","mycity");
	}
}
if (isset($_GET['sendsms'])) {
    
	$to = str_replace("+","", sanitize_text_field($_GET['sendsms']));
	if (!is_numeric($to)) die("Enter valid number");
	$code = rand(1111,9999);
	
	$user = get_user_by( "email", $to."@".$_SERVER['HTTP_HOST']);
	
	if ($user) {
		wp_set_password( $code, $user->ID);
	} else {
		$user = wp_create_user($to, $code, $to."@".$_SERVER['HTTP_HOST']);
		//print_R($user);
	}
	// Authorisation details.
	$message = $_SERVER['HTTP_HOST']." : Your code is ".$code;
	$return = mycity_send_sms($to,$message);
}

if (isset($_GET['check_email'])) {
	if (email_exists($_POST['email'])) { echo esc_html__("This email already registered","mycity"); } else { echo "OK"; }
}
if (isset($_GET['trylogin'])) {
	$creds = array();
	
	if (substr_count($_POST['login'],'+') && get_option("allow_sms_registration") == 1) {
		$to = str_replace("+","", sanitize_text_field($_POST['login']));
		if (!is_numeric($to)) die("enter valid tel");
		$creds['user_login'] = $to;
		$creds['user_email'] = $to."@".$_SERVER['HTTP_HOST'];
		
	} else if (substr_count($_POST['login'],'@')) {
		$creds['user_email'] =  sanitize_text_field($_POST['login']);
		$user = get_user_by( "email",sanitize_email( $creds['user_email']));
		if (isset($user->user_login)) { $creds['user_login'] = $user->user_login; } else {$creds['user_login'] = $_POST['login'];}
	} else {
		$creds['user_login'] =  sanitize_text_field($_POST['login']);
	}
	
	$creds['user_password'] =  sanitize_text_field($_POST['pass']);
	$creds['remember'] = true;
	$user = wp_signon( $creds, false );
	if ( is_wp_error($user) ) {
		echo $user->get_error_message();
	} else {
		$userID = $user->ID;
		wp_set_current_user( $userID, $user_login );
		wp_set_auth_cookie( $userID, true, false );
		do_action( 'wp_login', $user_login );
	       $place = "/places/";
        if(strlen(fmr_get_permalink_by_template('Places_map2.php')) > 1){
            $place = fmr_get_permalink_by_template('Places_map2.php');
        }
        if(strlen(fmr_get_permalink_by_template('Places_map.php')) > 1){
            $place = fmr_get_permalink_by_template('Places_map.php');
         }
    
        ?>
        <script>

            window.location = '<?php echo esc_url($place); ?>';
        </script>
		<?php
	}

}
if (isset($_GET['tryreg'])){
	$user_name = sanitize_user($_POST['display_name']);
	
	$user_id = username_exists($user_name);
	if (substr_count($_POST['login'],"@")) $_POST['regemail'] =sanitize_text_field($_POST['login']);
	$user_email = sanitize_email($_POST['regemail']);
	
	if ( !$user_id and email_exists($_POST['regemail']) == false ) {
		$random_password = wp_generate_password( $length=6, $include_standard_special_chars=false );
		if ($_POST['pass']) $random_password = $_POST['pass'];
		$user_email = $_POST['regemail'];
		//print_R($_POST);
		//die();
		$user_id = wp_create_user( $user_name, $random_password, $user_email );
		
		wp_set_current_user( $user_id, sanitize_user($user_name) );
		wp_set_auth_cookie( $user_id, true, false );
		do_action( 'wp_login', $user_login );
	
		wp_new_user_notification( $user_id, $random_password );
	 
        $place = "/places/";
        if(strlen(fmr_get_permalink_by_template('Places_map2.php')) > 1){
            $place = fmr_get_permalink_by_template('Places_map2.php');
        }
        if(strlen(fmr_get_permalink_by_template('Places_map.php')) > 1){
            $place = fmr_get_permalink_by_template('Places_map.php');
         }
    
        ?>
        <script>

            window.location = '<?php echo esc_url($place); ?>';
        </script>
        <?php
	} else {
		echo __('User already exists.','mycity');
	}
	
}

if (isset($_GET['editmain'])) { 
	//print_R($_POST);
	if (current_user_can('administrator')) {
		update_option(sanitize_text_field($_POST['option']),sanitize_text_field(strip_tags($_POST['val'])));
		echo get_option(sanitize_text_field($_POST['option']));
	} else {
	echo "123";
	}
}
?>