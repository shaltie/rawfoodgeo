<?php 

ignore_user_abort(true);

if ( !defined('ABSPATH') ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
$upload_dir       = wp_upload_dir();
$upload_path      = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;

$file             = $_FILES['file'];

$imageinfo = getimagesize($_FILES['file']['tmp_name']);
if ($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg' && $imageinfo['mime'] !=
    'image/jpg' && $imageinfo['mime'] != 'image/png') {
    die('error 2 -');
    exit;
}


/*
$file['error']    = '';
$file['tmp_name'] = $upload_path . $hashed_filename;
$file['name']     = $hashed_filename;

$file['type']     = 'image/jpg';
$file['size']     = filesize( $upload_path . $hashed_filename );
*/


$uploadedfile = $file;
$movefile =  wp_handle_sideload( $uploadedfile,array('test_form' => FALSE));

$post_id = (int)$_GET['id'];
$post = get_post($post_id);

//if (!current_user_can('edit_post', $post_id))die("current_user_can error");


if ( $movefile ) {
	
    $wp_filetype = $movefile['type'];
    $filename = $movefile['file'];
    $wp_upload_dir = wp_upload_dir();
    $attachment = array(
        'guid' => $wp_upload_dir['url'] . '/' . basename( $filename ),
        'post_mime_type' => $wp_filetype,
        'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
        'post_content' => '',
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment( $attachment, $filename);
	$allpostmeta=get_post_custom($_GET['id']);
	global $_GET;
	if ($_GET['x'] == 'small') {
		echo 'update_post_meta - '.esc_html( $post_id).'_small_img';
		update_post_meta($post_id, '_small_img',  $attach_id);
	} else {
		update_post_meta($post_id, '_big_img',  $attach_id);
	}
} else {
echo "error 432";
}
var_dump(get_post_meta($post_id, '_small_img'));

echo esc_html( $attach_id);
?>