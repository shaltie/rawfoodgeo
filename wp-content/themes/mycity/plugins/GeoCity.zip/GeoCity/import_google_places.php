<?php


function mycity_my_appearance_menu_item_gp() {
	add_submenu_page( 'edit.php?post_type=places', esc_html__( 'import from google places', 'mycity' ), esc_html__( 'import from google places', 'mycity' ),
		'manage_categories', 'import from google places2', 'mycity_wp_importer_geocity_gp' );


}

add_action( 'admin_menu', 'mycity_my_appearance_menu_item_gp' );


function mycity_wp_importer_geocity_gp() {
	?>
	<div style="padding:20px;background-color:white;

        margin-bottom: 2px;
margin-left: 15px;
margin-right: 15px;
margin-top: 5px;
        ">
		<?php

		_e( 'Press the button for import', 'mycity' );


		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once( ABSPATH . '/wp-admin/includes/file.php' );
			WP_Filesystem();
		}

		if ( isset( $_POST['place_category'] ) and ! empty( $_POST['place_category'] ) ) {
			$_SESSION['place_category'] = $_POST['place_category'];
		}

		if ( isset( $_POST['key'] ) and ! empty( $_POST['key'] ) ) {
			update_option( 'mycity_google_api_key', sanitize_text_field( $_POST['key'] ) );
		}
		$google_key = '';
		if ( isset( $_POST['key'] ) and ! empty( $_POST['key'] ) ) {
			$google_key = $_POST['key'];

		} else {

			$google_key = get_option( 'mycity_google_api_key' );
		}
		?>


		<form action="" method="post" class="">

			<div class="form-group">
				<h3><?php esc_html_e( 'Video instruction', 'mycity' ); ?>
				</h3>
				<?php echo do_shortcode( '[video src="https://youtu.be/pObGvi6W1kU"]' ); ?>
			</div>
			<div class="osm_form">
				<input type="hidden" name="wfm_hidenn" value="wmf_hiden"/>

				<div class="form-group">
					<label for="location_s"><?php esc_html_e( 'Select your city', 'mycity' ); ?>  </label>
					<input name="city" id="location_s" type="text" class="typeahead form-control" value="">
				</div>
				<div class="form-group">
					<label for="location_amenity"><?php esc_html_e( 'Select your amenity', 'mycity' ); ?>  </label>
					<input name="amenity" id="location_amenity" type="text" class="typeahead2 form-control" value="">
				</div>
				<div class="form-group">
					<label for="category"><?php esc_html_e( 'Select your Places category', 'mycity' ); ?>  </label>
					<?php
					$cats = get_terms( 'places_categories', array(
						'hide_empty' => false,
					) );


					?>
					<select name='place_category' id='category' class="selectpicker form-control">
						<option value="-1">——–</option>
						<?php
						$cat_get = ( isset( $_SESSION['place_category'] ) ) ? (int) $_SESSION['place_category'] : "";
						foreach ( $cats as $cat ) {

							?>
							<option
								value='<?php echo (int) $cat->term_id ?>' <?php if ( (int) $cat->term_id == $cat_get ) {
								echo 'selected="selected"';
							} ?>><?php echo esc_html( $cat->name ); ?></option>
						<?php } ?>
					</select>
				</div>
				<div class="form-group">
					<label for="location_amenity"><?php esc_html_e( 'insert your google api key', 'mycity' ); ?> <a
							target="_blank"
							href="https://developers.google.com/places/web-service/get-api-key"><?php esc_html_e( 'Where to get?', 'mycity' ); ?></a>
					</label>
					<input name="key" id="location_amenity_api_key" type="text" class="typeahead2 form-control"
					       value="<?php if ( get_option( 'mycity_google_api_key' ) ) {
						       echo get_option( 'mycity_google_api_key' );
					       } ?>">
				</div>
			</div>
			<?php

			if ( isset( $_POST ) and ! empty( $_POST ) ) {
			global $wp_error;

			//import selected post
			if ( isset( $_POST['post'][0] ) ) {

				foreach ( $_POST['post'] as $item ) {

					$element = json_decode( base64_decode( $item ) );
					// var_dump($element);

					/************************************************************************/

					$phone   = '';
					$website = '';


					$my_post = array(
						'post_title'   => sanitize_text_field( $element->name ),
						'post_content' => '',
						'post_status'  => 'publish', //change draft to publish
						'post_author'  => (int) get_current_user_id(),
						'post_type'    => 'places',

					);

					/**
					 * if the user is not authorized, we will send it to the login page.
					 */


					$mycity_post_ID = wp_insert_post( $my_post, $wp_error );


					if ( ! is_wp_error( $mycity_post_ID ) ) {

						if ( isset( $element->photos[0]->photo_reference ) ) {
							$img = 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=1928&photoreference=' . $element->photos[0]->photo_reference . '&key=' . $google_key;

							$url               = mycity_get_furl( $img );
							$mycity_upload_dir = wp_upload_dir();
							$img               = md5( time() );
							file_put_contents( $mycity_upload_dir["basedir"] . '/' . $img . '.png', file_get_contents( $url ) );

							$data = mycity_upload_img_from_url( $mycity_upload_dir["baseurl"] . '/' . $img . '.png' );
							unlink( $mycity_upload_dir["basedir"] . '/' . $img . '.png' );

							if ( ! is_wp_error( $data ) ) {
								update_post_meta( $mycity_post_ID, '_big_img', $data->attachment_id );
							}


						}


						wp_set_object_terms( $mycity_post_ID, array( (int) $_POST['place_category'] ),
							"places_categories" );
						update_post_meta( $mycity_post_ID, '_myfield', $element->geometry->location->lat . ',' . $element->geometry->location->lng );
						update_post_meta( $mycity_post_ID, '_adress', $element->formatted_address );

						$query = 'https://maps.googleapis.com/maps/api/place/details/json?placeid=' . $element->place_id . '&key=' . $google_key;

						$res = wp_remote_get( $query );

						if ( ! is_wp_error( $res ) ) {
							$res2 = json_decode( $res['body'] );


							if ( isset( $res2->result->international_phone_number ) ) {
								update_post_meta( $mycity_post_ID, '_meta_phone', sanitize_text_field( $res2->result->international_phone_number ) );
							}

							if ( isset( $res2->result->website ) ) {
								update_post_meta( $mycity_post_ID, '_meta_website', sanitize_text_field( $res2->result->website ) );
							}

						}


					}
					echo esc_html( "Places added ", 'mycity' ) . sanitize_text_field( $element->name );

					echo "\n<br/><br/>";
					/*===================================================================*/

				}


			}
			$base_res = null;
			// get nodes by city and cats
			if ( isset( $_POST['city']{2} ) ) {
				$city    = sanitize_text_field( $_POST['city'] );
				$amenity = sanitize_text_field( $_POST['amenity'] );
				$query   = 'https://maps.googleapis.com/maps/api/place/textsearch/json?query=' . $city . '+' . $amenity . '&key=' . $google_key;
				$query   = str_replace( ' ', '+', $query );
				$res     = wp_remote_get( $query );


				if ( ! is_wp_error( $res ) ) {
					$res2     = json_decode( $res['body'] );
					$base_res = $res2;
					if ( isset( $res2->error_message ) ) {
						echo $res2->error_message;
					}
				} else {
					echo $res->get_error_message();
				}


			}


			?>
			<table class="wp-list-table widefat fixed striped pages">
				<thead>
				<?php if ( isset( $res2->results ) ) { ?>
					<tr>
						<td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text"
						                                                                for="cb-select-all-1">Select
								All</label><input id="cb-select-all-1" type="checkbox"></td>

					</tr>
				<?php } ?>
				</thead>

				<tbody id="the-list">

				<?php if ( isset( $res2->results ) ) {
					$i = 1;
					foreach ( $res2->results as $element ) {

						if ( 1 < 2 ) { ?>
							<tr id="post-<?php echo esc_html( $element->id ); ?>"
							    class="iedit author-self level-0 post-<?php echo esc_html( $element->id ); ?> type-page status-publish hentry">
								<th scope="row" class="check-column">

									<label class="screen-reader-text"
									       for="cb-select-<?php echo esc_html( $element->id ); ?>">Select
										chat</label>
									<input id="cb-select-<?php echo esc_html( $element->id ); ?>" type="checkbox"
									       name="post[]" value='<?php

									echo base64_encode( json_encode( $element ) );

									?>'>
									<div class="locked-indicator"></div>
								</th>
								<td class="title column-title has-row-actions column-primary page-title"
								    data-colname="Title">
									<label
										for="cb-select-<?php echo esc_html( $element->id ); ?>">
										<?php echo wp_kses_post( $i . ') <b>' . $element->name . '</b>' );
										?>
									</label>
								</td>
								<td class="author column-author"
								    data-colname="Author">
									<?php
									if ( isset( $element->photos[0]->photo_reference ) ) {
										?>
										<img style="max-height: 120px;"
										     src="<?php echo 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=1928&photoreference=' . $element->photos[0]->photo_reference . '&key=' . $google_key; ?>"
										     alt="">
										<?php
									}

									$query = 'https://maps.googleapis.com/maps/api/place/details/json?placeid=' . $element->place_id . '&key=' . $google_key;

									$res = wp_remote_get( $query );
									if ( ! is_wp_error( $res ) ) {


										$res2 = json_decode( $res['body'] );

										if ( ! is_wp_error( $res2 ) ) {
											if ( isset( $res2->result->formatted_address ) ) {
												echo $res2->result->formatted_address . '<br>';
											}
											if ( isset( $res2->result->international_phone_number ) ) {
												echo 'international_phone_number ' . $res2->result->international_phone_number . '<br>';
											}

											if ( isset( $res2->result->website ) ) {
												echo $res2->result->website . '<br>';
											}
										}
									}


									?>
								</td>
							</tr>

							<?php

							++ $i;
						}

					}
				}

				}


				?>

				</tbody>


			</table>
			<?php

			if ( isset( $base_res->next_page_token ) ) {
				?>
				<button id="import_places_button_more" class="btn button-primary "
				        data-token="<?php echo $base_res->next_page_token; ?>">Show more places
				</button>
				<?php
			}
			if ( isset( $_POST['city']{2} ) ) {
				submit_button( esc_html__( "Start import", 'mycity' ) );

			} else {
				submit_button( esc_html__( "Get nodes", 'mycity' ) );
			}
			?>
		</form>
	</div>
	<script>

		jQuery(document).ready(function ($) {


			$('.typeahead').typeahead({
				source: mycity_gp_obj.location

			});
			$('.typeahead2').typeahead({
				source: mycity_gp_obj.types

			});

			$('#import_places_button_more').click(function (e) {
				e.preventDefault();
				jQuery('#import_places_button_more').prop('disabled', true);
				var mytis = $(this);
				var token = mytis.data('token');
				var count = jQuery('.iedit ').length;
				$.ajax({
					url: "<?php echo esc_url( site_url() ); ?>/wp-admin/admin-ajax.php",
					type: 'POST',
					data: "action=mycity_ajax_get_google_places&token=" + token + '&api_key=' + $('#location_amenity_api_key').val() +
					'&count=' + count,
					success: function (html) {
						var obj = jQuery.parseJSON(html);
						$('#the-list').append(obj.res_places);
						mytis.data('token', obj.new_token);
						if(obj.new_token !=''){
							jQuery('#import_places_button_more').prop('disabled', false);
						}


					}
				});
			});
			/********************** ajax **********************/

		});
	</script>
	<style>
		#import_places_button_more {
			display: block;
			width: 250px;
			font-size: 16px;
			padding: 0px;
			height: 40px;
			margin: 0 auto !important;
			margin-top: 90px !important;
			clear: top !important;
		}

	</style>
	<?php
}


/*
 * ыскшзеы оы
 */

function mycity_gp_enqueue( $hook ) {

	if ( 'places_page_import from google places2' != $hook ) {
		return;
	}


	global $wp_filesystem;
	if ( empty( $wp_filesystem ) ) {
		require_once( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
	}

	$con     = $wp_filesystem->get_contents( plugin_dir_path( __FILE__ ) . "/interpreter.json" );
	$amenity = $wp_filesystem->get_contents( plugin_dir_path( __FILE__ ) . "/amenity.json" );

	wp_enqueue_style( 'mycity_2bootstrap', plugin_dir_url( __FILE__ ) .
	                                       "/css/style.css" );

	wp_enqueue_script( 'mycity_gp_bootstrap3_typeahead', plugin_dir_url( __FILE__ ) .
	                                                     '/js/bootstrap3-typeahead.min.js', array( 'jquery' ) );

	wp_enqueue_script( 'mycity_gp_bootstrap3_typeahead', plugin_dir_url( __FILE__ ) .
	                                                     '/js/bootstrap3-typeahead.min.js', array( 'jquery' ) );

	$str     = "accounting
airport
amusement_park
aquarium
art_gallery
atm
bakery
bank
bar
beauty_salon
bicycle_store
book_store
bowling_alley
bus_station
cafe
campground
car_dealer
car_rental
car_repair
car_wash
casino
cemetery
church
city_hall
clothing_store
convenience_store
courthouse
dentist
department_store
doctor
electrician
electronics_store
embassy
establishment
finance
fire_station
florist
food
funeral_home
furniture_store
gas_station
general_contractor
grocery_or_supermarket
gym
hair_care
hardware_store
health
hindu_temple
home_goods_store
hospital
insurance_agency
jewelry_store
laundry
lawyer
library
liquor_store
local_government_office
locksmith
lodging
meal_delivery
meal_takeaway
mosque
movie_rental
movie_theater
moving_company
museum
night_club
painter
park
parking
pet_store
pharmacy
physiotherapist
place_of_worship
plumber
police
post_office
real_estate_agency
restaurant
roofing_contractor
rv_park
school
shoe_store
shopping_mall
spa
stadium
storage
store
subway_station
synagogue
taxi_stand
train_station
travel_agency
university
veterinary_care
zoo";
	$str_arr = explode( "\n", $str );

	wp_localize_script( 'mycity_gp_bootstrap3_typeahead', 'mycity_gp_obj',
		array(

			'location' => json_decode( $con ),
			'amenity'  => json_decode( $amenity ),
			'types'    => $str_arr,
		) );
}

add_action( 'admin_enqueue_scripts', 'mycity_gp_enqueue' );
/**
 * @param $street
 *
 * @return array lat lng from street
 */
function mycity_gp_get_street_from_lat_lng( $street ) {
	flush();
	//https://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&key=YOUR_API_KEY
	$google_key = '';
	if ( isset( $_POST['key'] ) && ! empty( $_POST['key'] ) ) {
		$google_key = $_POST['key'];
	} else {

		$google_key = get_option( 'mycity_google_api_key' );
	}
	$url           = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . urlencode( $street ) . '&key=' . $google_key;
	$arr_locations = @json_decode( ( wp_remote_get( $url )['body'] ) );
	if ( isset( $arr_locations->results[0]->formatted_address ) ) {
		return ( $arr_locations->results[0]->formatted_address );
	} else {
		return false;
	}

}

function mycity_get_furl( $url ) {
	$furl = false;
	// First check response headers
	$headers = get_headers( $url );
	// Test for 301 or 302
	if ( preg_match( '/^HTTP\/\d\.\d\s+(301|302)/', $headers[0] ) ) {
		foreach ( $headers as $value ) {
			if ( substr( strtolower( $value ), 0, 9 ) == "location:" ) {
				$furl = trim( substr( $value, 9, strlen( $value ) ) );
			}
		}
	}
	// Set final URL
	$furl = ( $furl ) ? $furl : $url;

	return $furl;
}


/******************************************** AJAX **********************/

function mycity_ajax_get_google_places() {

	if ( isset( $_POST['token']{4} ) ) {

		/**
		 * sed requst to get places object
		 */
		$google_key = $_POST['api_key'];
		$res_places = '';
		$new_token  = ''; // page token
		$eroor      = false;

		$city    = sanitize_text_field( $_POST['city'] );
		$amenity = sanitize_text_field( $_POST['amenity'] );

		$query = 'https://maps.googleapis.com/maps/api/place/textsearch/json?query=' . $city . '+' . $amenity . '&pagetoken=' . $_POST['token'] . '&key=' . $google_key;

		$query = str_replace( ' ', '+', $query );
		$res   = wp_remote_get( $query );
//var_dump($res);

		if ( ! is_wp_error( $res ) ) {
			$res2 = json_decode( $res['body'] );

			if ( isset( $res2->next_page_token ) ) {
				$new_token = $res2->next_page_token;
			}
			if ( isset( $res2->results ) ) {
				$i = $_POST['count'] + 1;
				ob_start();
				foreach ( $res2->results as $element ) {

					if ( 1 < 2 ) { ?>
						<tr id="post-<?php echo esc_html( $element->id ); ?>"
						    class="iedit author-self level-0 post-<?php echo esc_html( $element->id ); ?> type-page status-publish hentry">
							<th scope="row" class="check-column">

								<label class="screen-reader-text"
								       for="cb-select-<?php echo esc_html( $element->id ); ?>">Select
									chat</label>
								<input id="cb-select-<?php echo esc_html( $element->id ); ?>" type="checkbox"
								       name="post[]" value='<?php

								echo base64_encode( json_encode( $element ) );

								?>'>
								<div class="locked-indicator"></div>
							</th>
							<td class="title column-title has-row-actions column-primary page-title"
							    data-colname="Title">
								<label
									for="cb-select-<?php echo esc_html( $element->id ); ?>">
									<?php echo wp_kses_post( $i . ') <b>' . $element->name . '</b>' );
									?>
								</label>
							</td>
							<td class="author column-author"
							    data-colname="Author">
								<?php
								if ( isset( $element->photos[0]->photo_reference ) ) {
									?>
									<img style="max-height: 120px;"
									     src="<?php echo 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=1928&photoreference=' . $element->photos[0]->photo_reference . '&key=' . $google_key; ?>"
									     alt="">
									<?php
								}

								$query = 'https://maps.googleapis.com/maps/api/place/details/json?placeid=' . $element->place_id . '&key=' . $google_key;

								$res = wp_remote_get( $query );
								if ( ! is_wp_error( $res ) ) {


									$res2 = json_decode( $res['body'] );

									if ( ! is_wp_error( $res2 ) ) {
										if ( isset( $res2->result->formatted_address ) ) {
											echo $res2->result->formatted_address . '<br>';
										}
										if ( isset( $res2->result->international_phone_number ) ) {
											echo 'international_phone_number ' . $res2->result->international_phone_number . '<br>';
										}

										if ( isset( $res2->result->website ) ) {
											echo $res2->result->website . '<br>';
										}
									}
								}


								?>
							</td>
						</tr>

						<?php

						++ $i;
					}

				}

				$res_places = ob_get_clean();
			}


		} else {
			$res_places = $res->get_error_message();

		}

		$arr_response = array(
			'res_places' => $res_places,
			'new_token'  => $new_token
		);
		echo wp_json_encode( $arr_response );
	}
	exit;
	die();
}

add_action( 'wp_ajax_mycity_ajax_get_google_places', 'mycity_ajax_get_google_places' ); // for logged in user
add_action( 'wp_ajax_nopriv_mycity_ajax_get_google_places', 'mycity_ajax_get_google_places' ); // if user not logged in
