This is project for Cordova builder. (beta)

Android generation:
Just go Admin panel of your wordpress -> Mobile app

Ios:

Unfortunately the automatic generation of applications for Apple iPhone is not possible :( 

You will need a Mac computer and iPhone. See more information at https://cordova.apache.org/docs/en/5.0.0/guide_platforms_ios_index.md.html#iOS%20Platform%20Guide 

